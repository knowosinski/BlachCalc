import json
import tempfile
import sqlite3
import tkinter as tk
import time
from contextlib import closing
from datetime import date, datetime
from decimal import Decimal
from tkinter import ttk
import unittest
from pathlib import Path
from unittest.mock import patch

from ui_harness import SharedAppTestCase


class AppUiTests(SharedAppTestCase):
    def test_navigation_arrows_home_and_refresh_buttons(self) -> None:
        self.view._show_page("quote")
        self.view._show_page("history")
        self.view._show_page("customers")
        self.assertEqual(str(self.view.back_button.cget("state")), "normal")
        self.view.back_button.invoke()
        self.assertEqual(self.view.current_page, "history")
        self.view.back_button.invoke()
        self.assertEqual(self.view.current_page, "quote")
        self.view.forward_button.invoke()
        self.assertEqual(self.view.current_page, "history")
        self.view.home_button.invoke()
        self.assertEqual(self.view.current_page, "quote")
        self.assertEqual(str(self.view.forward_button.cget("state")), "disabled")
        self.view.refresh_button.invoke()
        self.assertEqual(self.view.current_page, "quote")

    def test_packaging_is_added_to_saved_estimate_and_not_duplicated_on_edit(self) -> None:
        self.view.settings["packaging_price_pallet_a"] = "90"
        self.view.item_vars["element_name"].set("Detal")
        self.view.item_vars["used_weight_kg"].set("1")
        self.view.add_item()
        self.view.customer_var.set("KADAM")
        self.view.order_number_var.set("PAK/1")
        with patch.object(self.view, "_ask_packaging", return_value="pallet_a"):
            self.view.save_estimate()
        estimate = self.storage.get_estimate(self.user_id, self.view.editing_estimate_id)
        self.assertEqual([item["element_name"] for item in estimate["items"]], ["Detal", "Opakowanie: Paleta A"])
        self.assertEqual(estimate["items"][1]["line_net"], "90.00")

        self.view._open_delivery_note(estimate)
        self.assertEqual(len(self.view.delivery_note_rows), 1)
        self.assertEqual(self.view.issued_packages_text.get("1.0", "end-1c"), "Paleta A — 90,00 zł netto")

        self.view._load_estimate_into_form(estimate, copy=False)
        self.assertEqual(len(self.view.draft_items), 1)
        self.assertEqual(self.view.packaging_choice, "pallet_a")

    def test_bending_count_field_is_conditional_and_adds_three_zloty_per_bend(self) -> None:
        from quote_domain import OPERATIONS

        self.view.operation_var.set(OPERATIONS["bending"])
        self.view._update_calculation_form()
        self.app.update()
        self.assertTrue(self.view.bending_count_cell.winfo_ismapped())
        self.assertEqual(self.view.bending_price_var.get(), "3,00 zł")
        self.assertEqual(str(self.view.bending_price_entry.cget("state")), "readonly")
        self.assertTrue(self.view.bending_price_entry.winfo_ismapped())

        self.view.item_vars["element_name"].set("Wspornik")
        self.view.item_vars["used_weight_kg"].set("1")
        self.view.item_vars["quantity"].set("3")
        self.view.item_vars["bending_count"].set("2")
        self.view.add_item()

        item = self.view.draft_items[0]
        self.assertEqual(item["bending_count"], 2)
        self.assertEqual(item["bending_cost"], "18.00")
        self.assertEqual(item["bending_unit_price"], "3.00")
        self.assertEqual(item["line_net"], "32.10")

        self.view.operation_var.set(OPERATIONS["cutting"])
        self.view._update_calculation_form()
        self.app.update()
        self.assertFalse(self.view.bending_count_cell.winfo_ismapped())

    def test_offer_page_editor_saves_edited_text(self) -> None:
        self.view.open_offer_page_editor(self.app)
        self.app.update()
        dialog = next(w for w in self.app.winfo_children() if isinstance(w, tk.Toplevel))

        def walk(widget):
            for child in widget.winfo_children():
                yield child
                yield from walk(child)

        boxes = [w for w in walk(dialog) if isinstance(w, tk.Text)]
        self.assertEqual(len(boxes), 3)
        boxes[0].delete("1.0", "end")
        boxes[0].insert("1.0", "Jedyny warunek\n\nDrugi")

        def find_button(text):
            return next(
                widget
                for widget in walk(dialog)
                if isinstance(widget, ttk.Button) and widget.cget("text") == text
            )

        find_button("+  Dodaj rubrykę").invoke()
        self.app.update()
        boxes = [widget for widget in walk(dialog) if isinstance(widget, tk.Text)]
        custom_box = next(widget for widget in boxes if widget.get("1.0", "end-1c") == "")
        custom_box.insert("1.0", "Treść dodatkowej rubryki")
        custom_title = next(
            widget for widget in custom_box.master.winfo_children()
            if isinstance(widget, ttk.Entry)
        )
        custom_title.insert(0, "Zakres usługi")
        find_button("+  Dodaj rubrykę").invoke()
        self.app.update()
        remove_custom_buttons = [
            widget for widget in walk(dialog)
            if isinstance(widget, ttk.Button) and widget.cget("text") == "Usuń rubrykę"
        ]
        self.assertEqual(len(remove_custom_buttons), 2)
        remove_custom_buttons[-1].invoke()

        find_button("+  Dodaj osobę kontaktową").invoke()
        self.app.update()
        remove_buttons = [
            widget for widget in walk(dialog)
            if isinstance(widget, ttk.Button) and widget.cget("text") == "Usuń"
        ]
        self.assertEqual(len(remove_buttons), 2)
        remove_buttons[0].invoke()
        self.app.update()
        find_button("+  Dodaj osobę kontaktową").invoke()
        self.app.update()
        remove_buttons = [
            widget for widget in walk(dialog)
            if isinstance(widget, ttk.Button) and widget.cget("text") == "Usuń"
        ]
        contact_entries = [
            widget for widget in remove_buttons[0].master.winfo_children()
            if isinstance(widget, ttk.Entry)
        ]
        for entry, value in zip(contact_entries, ("Anna Nowak", "123 456 789", "anna@example.com")):
            entry.insert(0, value)

        save = next(w for w in walk(dialog) if isinstance(w, ttk.Button) and w.cget("text") == "Zapisz")
        save.invoke()
        self.app.update()
        from offer_page import parse_offer_page

        page = parse_offer_page(self.view.settings["offer_page2"])
        self.assertEqual(page["terms"]["items"], ["Jedyny warunek", "Drugi"])
        self.assertEqual(page["claims"]["title"], "Odbiór i reklamacje towaru")
        self.assertEqual(page["custom_sections"], [{
            "title": "Zakres usługi",
            "text": "Treść dodatkowej rubryki",
        }])
        self.assertEqual(page["contacts"], [{
            "person": "Anna Nowak",
            "phone": "123 456 789",
            "email": "anna@example.com",
        }])

    def _add_items(self, count: int) -> None:
        for index in range(count):
            self.view.item_vars["element_name"].set(f"Element {index}")
            self.view.item_vars["used_weight_kg"].set("1")
            self.view.item_vars["seconds"].set("30")
            self.view.add_item()
        self.app.update()

    def test_wheel_scrolls_quote_form_from_anywhere_over_its_content(self) -> None:
        canvas = self.view.quote_canvas
        self.assertLess(canvas.yview()[1], 1.0)
        for state in (0, 0x0008):
            canvas.yview_moveto(0)
            self.app.update()
            self._wheel(self.view.customer_cell, state=state)
            self.assertGreater(canvas.yview()[0], 0.0, f"state={state:#x}")

    def test_wheel_scrolls_order_items_list_over_card_and_list(self) -> None:
        self._add_items(30)
        tree = self.view.draft_tree
        self.assertLess(tree.yview()[1], 1.0)
        for target in (tree, self.view.draft_card):
            tree.yview_moveto(0)
            self.app.update()
            self._wheel(target)
            self.assertGreater(tree.yview()[0], 0.0, str(target))

    def test_enter_moves_through_item_fields_in_visual_order(self) -> None:
        view = self.view
        expected = [
            view.item_field_cells["element_name"].winfo_children()[1],
            view.material_combo,
            view.item_field_cells["thickness_mm"].winfo_children()[1],
            view.quantity_entry,
            view.weight_entry,
            *view.dimensions_entries,
            *view.time_entries,
        ]
        for current, following in zip(expected, expected[1:]):
            current.focus_force()
            self.app.update()
            current.event_generate("<Return>")
            self.app.update()
            self.assertIs(self.app.focus_get(), following)

    def test_dimensions_fields_are_saved_and_restored_as_one_measurement(self) -> None:
        self.view.item_vars["element_name"].set("Wspornik")
        self.view.item_vars["used_weight_kg"].set("1")
        self.view.item_vars["dimension_1"].set("200")
        self.view.item_vars["dimension_2"].set("100")
        self.view.add_item()

        self.assertEqual(self.view.draft_items[0]["dimensions"], "200 x 100")
        self.view.draft_tree.selection_set("0")
        self.view.edit_draft_item()
        self.assertEqual(self.view.item_vars["dimension_1"].get(), "200")
        self.assertEqual(self.view.item_vars["dimension_2"].get(), "100")

    def test_second_dimension_cannot_be_entered_without_first_dimension(self) -> None:
        self.view.item_vars["element_name"].set("Wspornik")
        self.view.item_vars["used_weight_kg"].set("1")
        self.view.item_vars["dimension_2"].set("100")

        with self.assertRaisesRegex(ValueError, "pierwszy wymiar"):
            self.view._build_item_from_form()

    def test_dark_theme_setting_is_saved_and_updates_the_application(self) -> None:
        from dashboard_shared import ACCENT, BACKGROUND, BORDER, theme_color

        combo = self.view.customer_combo
        popup = combo.tk.call("ttk::combobox::PopdownWindow", str(combo))
        popup_listbox = f"{popup}.f.l"
        self.view.theme_button.invoke()
        self.app.update()
        self.view.open_settings()
        self.app.update()
        dialog = next(
            child for child in self.view.winfo_children() if isinstance(child, tk.Toplevel)
        )

        def walk(widget):
            for child in widget.winfo_children():
                yield child
                yield from walk(child)

        self.assertFalse(any(
            isinstance(widget, ttk.Checkbutton)
            and widget.cget("text") == "Używaj ciemnego motywu"
            for widget in walk(dialog)
        ))
        self.assertEqual(
            self.storage.get_settings(self.view.user_id)["dark_mode"],
            "1",
        )
        self.assertEqual(
            self.view.quote_canvas.cget("background"),
            theme_color(BACKGROUND, True),
        )
        self.assertEqual(
            ttk.Style(self.app).lookup("TEntry", "fieldbackground"),
            theme_color("#FFFFFF", True),
        )
        style = ttk.Style(self.app)
        self.assertEqual(
            style.lookup("TEntry", "fieldbackground", ("readonly",)),
            theme_color("#FFFFFF", True),
        )
        self.assertEqual(
            style.lookup("TEntry", "foreground", ("readonly",)),
            theme_color("#172B4D", True),
        )
        self.assertEqual(
            style.lookup("TCombobox", "arrowcolor", ("active",)),
            theme_color(ACCENT, True),
        )
        self.assertEqual(
            style.lookup("TCheckbutton", "indicatorbackground", ("selected",)),
            theme_color(ACCENT, True),
        )
        self.assertEqual(
            style.lookup("Horizontal.TScale", "troughcolor"),
            theme_color(BORDER, True),
        )
        self.assertEqual(
            style.lookup("Vertical.TScrollbar", "troughcolor"),
            style.lookup("Horizontal.TScale", "troughcolor"),
        )
        self.assertEqual(
            style.lookup("Horizontal.TScrollbar", "bordercolor"),
            style.lookup("Horizontal.TScale", "bordercolor"),
        )
        self.assertEqual(
            style.lookup("Horizontal.TProgressbar", "troughcolor"),
            theme_color(BORDER, True),
        )
        self.assertEqual(
            style.lookup("TCheckbutton", "background", ("active",)),
            theme_color("#F6F8FB", True, self.app._theme_settings),
        )
        self.assertEqual(
            style.lookup("TCheckbutton", "foreground", ("active",)),
            theme_color("#172B4D", True),
        )
        self.assertEqual(self.view.theme_button.cget("text"), "☀")
        history_detail_label = next(
            widget
            for widget in self._walk_widgets(self.view.history_options)
            if isinstance(widget, ttk.Label)
            and widget.cget("textvariable") == str(self.view.history_detail)
        )
        self.assertEqual(
            history_detail_label.master.cget("background"),
            style.lookup(history_detail_label.cget("style"), "background"),
        )
        self.assertEqual(
            style.lookup(history_detail_label.cget("style"), "foreground"),
            theme_color("#172B4D", True),
        )
        self.assertEqual(history_detail_label.master.cget("highlightthickness"), 1)
        self.assertEqual(self.view.theme_button.master.cget("highlightthickness"), 1)
        self.assertEqual(self.view.draft_card.cget("highlightthickness"), 2)
        self.assertEqual(self.view.draft_tree.master.cget("highlightthickness"), 1)
        self.assertEqual(
            combo.tk.call(popup_listbox, "cget", "-background"),
            theme_color("#FFFFFF", True),
        )

        dialog.destroy()
        self.view.theme_button.invoke()
        self.app.update()
        self.assertEqual(
            self.storage.get_settings(self.view.user_id)["dark_mode"],
            "0",
        )
        self.assertEqual(self.view.theme_button.cget("text"), "☾")
        self.assertEqual(
            style.lookup("TEntry", "fieldbackground", ("readonly",)),
            "#FFFFFF",
        )
        self.assertEqual(
            style.lookup("TEntry", "foreground", ("readonly",)),
            "#172B4D",
        )
        self.assertEqual(
            style.lookup("TCombobox", "fieldbackground", ("readonly",)),
            "#FFFFFF",
        )
        self.assertEqual(
            style.lookup("TCheckbutton", "background", ("active",)),
            "#F6F8FB",
        )
        self.assertEqual(
            history_detail_label.master.cget("background"),
            style.lookup(history_detail_label.cget("style"), "background"),
        )
        self.assertEqual(
            style.lookup(history_detail_label.cget("style"), "foreground"),
            "#172B4D",
        )
        self.assertEqual(
            style.lookup("TCombobox", "arrowcolor", ("active",)),
            ACCENT,
        )
        self.assertEqual(
            style.lookup("TCheckbutton", "indicatorbackground", ("selected",)),
            ACCENT,
        )
        self.assertEqual(
            combo.tk.call(popup_listbox, "cget", "-background"),
            "#FFFFFF",
        )
        for _ in range(10):
            time.sleep(0.02)
            self.app.update()
        self.assertIsNone(self.app._theme_fade_after_id)
        dialog.destroy()

    def test_custom_light_and_dark_palettes_are_applied(self) -> None:
        from dashboard_shared import contrasting_text_color

        self.assertEqual(contrasting_text_color("#FFFFFF"), "#172B4D")
        self.assertEqual(contrasting_text_color("#000000"), "#FFFFFF")
        original_settings = self.storage.get_settings(self.user_id)
        custom_settings = {
            **original_settings,
            "ui_light_background": "#010203",
            "ui_light_surface": "#112233",
            "ui_light_accent": "#445566",
            "ui_light_subtle": "#223344",
            "ui_dark_background": "#070809",
            "ui_dark_surface": "#0A0B0C",
            "ui_dark_accent": "#AABBCC",
            "ui_dark_subtle": "#334455",
        }
        try:
            self.app.set_theme(custom_settings, False, animate=False)
            self.assertEqual(self.app.cget("background"), "#010203")
            self.assertEqual(
                ttk.Style(self.app).lookup("TEntry", "fieldbackground"),
                "#112233",
            )
            self.assertEqual(
                ttk.Style(self.app).lookup("TCheckbutton", "indicatorbackground", ("selected",)),
                "#445566",
            )
            sample = tk.Frame(self.view, bg="#E7EDF4")
            self.app._apply_widget_theme(sample, False)
            self.assertEqual(sample.cget("background"), "#223344")

            self.app.set_theme(custom_settings, True, animate=False)
            self.assertEqual(self.app.cget("background"), "#070809")
            self.assertEqual(
                ttk.Style(self.app).lookup("TEntry", "fieldbackground"),
                "#0A0B0C",
            )
            self.assertEqual(
                ttk.Style(self.app).lookup("TCheckbutton", "indicatorbackground", ("selected",)),
                "#AABBCC",
            )
            self.app._apply_widget_theme(sample, True)
            self.assertEqual(sample.cget("background"), "#334455")
            sample.destroy()
        finally:
            self.app.set_theme(
                original_settings,
                original_settings.get("dark_mode") == "1",
                animate=False,
            )

    def test_appearance_tab_saves_and_applies_selected_palette(self) -> None:
        original_settings = self.storage.get_settings(self.user_id)
        was_dark = self.app._dark_mode
        dialog = None
        try:
            self.view.open_settings()
            self.app.update()
            dialog = next(
                child
                for child in self.view.winfo_children()
                if isinstance(child, tk.Toplevel)
            )
            notebooks = [
                widget
                for widget in self._walk_widgets(dialog)
                if isinstance(widget, ttk.Notebook)
            ]
            settings_notebook = notebooks[0]
            appearance_page = settings_notebook.nametowidget(
                settings_notebook.tabs()[3]
            )
            settings_notebook.select(appearance_page)
            self.app.update_idletasks()
            save_buttons = [
                widget
                for widget in self._walk_widgets(dialog)
                if isinstance(widget, ttk.Button)
                and widget.cget("text") == "Zapisz ustawienia"
            ]
            self.assertEqual(len(save_buttons), 1)
            settings_save_button = save_buttons[0]
            self.assertTrue(settings_save_button.winfo_ismapped())
            self.assertGreater(settings_save_button.winfo_width(), 0)
            close_button = next(
                widget
                for widget in self._walk_widgets(dialog)
                if isinstance(widget, ttk.Button)
                and widget.cget("text") == "Zamknij"
            )
            self.assertEqual(settings_save_button.master, close_button.master)

            accent_group = next(
                widget
                for widget in self._walk_widgets(appearance_page)
                if isinstance(widget, tk.LabelFrame)
                and widget.cget("text") == "Akcenty"
            )
            accent_sample = next(
                widget
                for widget in self._walk_widgets(accent_group)
                if isinstance(widget, tk.Label) and str(widget.cget("cursor")) == "hand2"
            )
            with patch(
                "dashboard_management.colorchooser.askcolor",
                return_value=((18, 52, 86), "#123456"),
            ):
                accent_sample.event_generate("<Button-1>")
                self.app.update()
            settings_save_button.invoke()
            self.app.update()

            settings = self.storage.get_settings(self.user_id)
            self.assertEqual(settings["ui_light_accent"], "#123456")
            self.assertEqual(accent_sample.cget("background"), "#123456")
            self.assertEqual(
                ttk.Style(self.app).lookup(
                    "TCheckbutton",
                    "indicatorbackground",
                    ("selected",),
                ),
                "#123456",
            )
            self.assertTrue(any(
                isinstance(widget, tk.Label)
                and widget.cget("text") == "Ustawienia zapisane i zastosowane."
                for widget in self._walk_widgets(appearance_page)
            ))
            accent_sample.event_generate("<Button-3>")
            self.app.update()
            self.assertEqual(accent_sample.cget("background"), "#173B63")
            settings_save_button.invoke()
            self.assertEqual(
                self.storage.get_settings(self.user_id)["ui_light_accent"],
                "#173B63",
            )
        finally:
            if dialog is not None and dialog.winfo_exists():
                dialog.destroy()
            self.storage.save_settings(self.user_id, original_settings)
            self.view.settings = self.storage.get_settings(self.user_id)
            self.app.set_theme(
                self.view.settings,
                was_dark,
                animate=False,
            )

    def test_whats_new_contains_only_recent_concise_updates(self) -> None:
        from version import WHATS_NEW

        self.assertLessEqual(len(WHATS_NEW), 3)
        self.assertIn("obramowanie", WHATS_NEW[0])
        self.assertIn("gięć", WHATS_NEW[1])
        self.assertIn("3 zł netto", WHATS_NEW[1])
        self.assertIn("Nie wyłączaj aplikacji", WHATS_NEW[2])

    def test_accent_outlines_are_around_tables_not_outer_cards(self) -> None:
        from dashboard_shared import ACCENT

        draft_outline = self.view.draft_tree.master
        history_outline = self.view.history_tree.master
        customer_outline = self.view.customers_tree.master

        for outline in (draft_outline, history_outline, customer_outline):
            with self.subTest(outline=outline):
                self.assertEqual(outline.cget("highlightthickness"), 1)
                self.assertEqual(outline.cget("highlightbackground"), ACCENT)

        self.assertEqual(self.view.draft_card.cget("highlightthickness"), 2)
        self.assertEqual(self.view.history_card.cget("highlightthickness"), 2)
        self.assertEqual(self.view.customers_card.cget("highlightthickness"), 2)

    def test_welcome_dialog_and_labels_follow_dark_theme(self) -> None:
        from dashboard_shared import WHITE, theme_color
        from refresh import UPDATED_FLAG

        was_dark = self.app._dark_mode
        self.app.set_dark_mode(True)
        try:
            with patch("dashboard_management.sys.argv", ["BlachCalc", UPDATED_FLAG]):
                self.view._maybe_show_welcome()
            self.app.update()
            dialog = next(
                child
                for child in self.view.winfo_children()
                if isinstance(child, tk.Toplevel)
            )
            expected_surface = theme_color(WHITE, True)
            self.assertEqual(dialog.cget("background"), expected_surface)
            labels = [
                widget
                for widget in self._walk_widgets(dialog)
                if isinstance(widget, tk.Label)
            ]
            self.assertTrue(labels)
            self.assertTrue(
                all(label.cget("background") == expected_surface for label in labels)
            )
            dialog.destroy()
        finally:
            self.app.set_dark_mode(was_dark)

    def test_application_test_window_shows_names_results_and_percentage(self) -> None:
        class FinishedProcess:
            returncode = 0

            @staticmethod
            def poll():
                return 0

        def fake_start_worker(event_file: Path) -> FinishedProcess:
            events = (
                {"event": "total", "total": 2},
                {"event": "start", "test": "test_sample.SampleTests.test_first"},
                {"event": "result", "test": "test_sample.SampleTests.test_first", "status": "PASS"},
                {"event": "progress", "done": 1, "total": 2},
                {"event": "start", "test": "test_sample.SampleTests.test_second"},
                {"event": "problem", "test": "test_sample.SampleTests.test_second", "details": "AssertionError"},
                {"event": "result", "test": "test_sample.SampleTests.test_second", "status": "FAIL"},
                {"event": "progress", "done": 2, "total": 2},
                {"event": "done", "ok": False, "run": 2, "failures": 1, "errors": 0, "skipped": 0},
            )
            event_file.write_text(
                "".join(json.dumps(event) + "\n" for event in events),
                encoding="utf-8",
            )
            return FinishedProcess()

        with patch(
            "dashboard_management.start_application_test_worker",
            side_effect=fake_start_worker,
        ):
            self.view.run_application_tests(self.app)
        self.app.update()
        dialog = next(
            child
            for child in self.app.winfo_children()
            if isinstance(child, tk.Toplevel)
        )
        self.assertTrue(
            any(
                isinstance(widget, ttk.Label)
                and widget.cget("text") == "Nie wyłączaj aplikacji podczas testowania."
                for widget in self._walk_widgets(dialog)
            )
        )
        for _ in range(20):
            time.sleep(0.03)
            self.app.update()

        results = next(
            widget
            for widget in self._walk_widgets(dialog)
            if isinstance(widget, tk.Text)
        )
        result_text = results.get("1.0", "end-1c")
        self.assertIn("SampleTests · test_first", result_text)
        self.assertIn("PASS", result_text)
        self.assertIn("SampleTests · test_second", result_text)
        self.assertIn("FAIL", result_text)
        self.assertIn("AssertionError", result_text)
        displayed_labels = [
            str(self.app.getvar(widget.cget("textvariable")))
            for widget in self._walk_widgets(dialog)
            if isinstance(widget, ttk.Label) and widget.cget("textvariable")
        ]
        self.assertTrue(any("100%" in label and "2 z 2" in label for label in displayed_labels))
        next(
            widget
            for widget in self._walk_widgets(dialog)
            if isinstance(widget, ttk.Button) and widget.cget("text") == "Zamknij"
        ).invoke()

    def test_hidden_test_demo_is_simulated_and_stops_with_global_shortcut(self) -> None:
        dialog = None
        self.view.notes_var.set("TesTDlugI")
        try:
            self.assertTrue(self.view.notes_entry.bind("<KeyRelease>"))
            with patch(
                "dashboard_management.start_application_test_worker"
            ) as start_worker:
                self.view._activate_hidden_test_demo(None)
                self.assertEqual(self.view.notes_var.get(), "")
                self.assertTrue(self.app._test_demo_armed)
                self.assertIsNone(self.app._simulated_test_stop)
                self.assertTrue(self.app.bind_all("<Control-Shift-e>"))
                self.view.notes_entry.focus_force()
                self.view.notes_entry.event_generate("<KeyPress-e>", state=5)
                self.app.update()
                dialog = next(
                    child
                    for child in self.app.winfo_children()
                    if isinstance(child, tk.Toplevel)
                    and "Testy aplikacji" in child.title()
                )
                self.assertFalse(self.app._test_demo_armed)
                start_worker.assert_not_called()
                self.assertIsNotNone(self.app._simulated_test_stop)
                labels = [
                    str(widget.cget("text"))
                    for widget in self._walk_widgets(dialog)
                    if isinstance(widget, ttk.Label)
                ]
                self.assertIn("DEMO", labels)
                self.assertIn("Nie wyłączaj aplikacji podczas testowania.", labels)
                for _ in range(20):
                    time.sleep(0.04)
                    self.app.update()
                result_text = next(
                    widget
                    for widget in self._walk_widgets(dialog)
                    if isinstance(widget, tk.Text)
                ).get("1.0", "end-1c")
                self.assertIn("PASS", result_text)

                results = next(
                    widget
                    for widget in self._walk_widgets(dialog)
                    if isinstance(widget, tk.Text)
                )
                results.focus_force()
                results.event_generate("<KeyPress-e>", state=5)
                self.app.update()
                self.assertIsNone(self.app._simulated_test_stop)
                next(
                    widget
                    for widget in self._walk_widgets(dialog)
                    if isinstance(widget, ttk.Button)
                    and widget.cget("text") == "Zamknij"
                ).invoke()
                dialog = None
        finally:
            self.app._test_demo_armed = False
            if dialog is not None and dialog.winfo_exists():
                stop = getattr(self.app, "_simulated_test_stop", None)
                if stop is not None:
                    stop()
                dialog.destroy()

    @staticmethod
    def _walk_widgets(widget):
        for child in widget.winfo_children():
            yield child
            yield from AppUiTests._walk_widgets(child)

    def test_choosing_item_photo_starts_in_configured_gallery_folder(self) -> None:
        with tempfile.TemporaryDirectory() as temporary_directory:
            gallery_directory = Path(temporary_directory) / "Galeria"
            gallery_directory.mkdir()
            self.view.settings["item_photo_directory"] = str(gallery_directory)
            with (
                patch("dashboard_quote.Path.home", return_value=Path(temporary_directory)),
                patch("dashboard_quote.filedialog.askopenfilename", return_value="") as file_dialog,
            ):
                self.view.choose_item_photo()

        self.assertEqual(file_dialog.call_args.kwargs["initialdir"], gallery_directory)

    def test_edited_draft_item_can_be_added_as_a_new_position_or_updated(self) -> None:
        self.view.item_vars["element_name"].set("Wspornik")
        self.view.item_vars["quantity"].set("5")
        self.view.item_vars["used_weight_kg"].set("1")
        self.view.add_item()
        self.assertEqual(len(self.view.draft_items), 1)

        self.view.draft_tree.selection_set("0")
        self.view.edit_draft_item()
        self.assertEqual(self.view.add_edited_item_button.winfo_manager(), "pack")
        self.view.item_vars["quantity"].set("6")
        self.view.add_edited_item_button.invoke()

        self.assertEqual(len(self.view.draft_items), 2)
        self.assertEqual(self.view.draft_items[0]["quantity"], 5)
        self.assertEqual(self.view.draft_items[1]["quantity"], 6)
        self.assertIsNone(self.view.editing_draft_index)
        self.assertEqual(self.view.add_edited_item_button.winfo_manager(), "")

        self.view.draft_tree.selection_set("0")
        self.view.edit_draft_item()
        self.view.item_vars["quantity"].set("7")
        self.view.add_item_button.invoke()

        self.assertEqual(len(self.view.draft_items), 2)
        self.assertEqual(self.view.draft_items[0]["quantity"], 7)
        self.assertEqual(self.view.draft_items[1]["quantity"], 6)

    def test_full_batch_keeps_mode_and_asks_for_weight_and_time_once(self) -> None:
        self.view.calculation_mode_var.set("full_batch")
        self.view._update_calculation_form()
        self.assertEqual(str(self.view.weight_entry.cget("state")), "disabled")
        for name, quantity in (("A", "2"), ("B", "4")):
            self.view.item_vars["element_name"].set(name)
            self.view.item_vars["quantity"].set(quantity)
            self.view.item_vars["has_holes"].set("1")
            self.view.item_vars["hole_diameters"].set("10, 12")
            self.view.add_item()
        self.assertEqual(self.view.calculation_mode_var.get(), "full_batch")
        self.assertEqual(self.view.draft_items[0]["hole_diameters"],         "10, 12")
        self.assertEqual(self.view.item_vars["has_holes"].get(), "0")

        with patch.object(self.view, "_ask_full_batch_totals", return_value=(Decimal("6"), 3600)):
            self.assertTrue(self.view._resolve_full_batch_weights())
        weights = [Decimal(item["used_weight_kg"]) for item in self.view.draft_items]
        self.assertEqual(sum(weights), Decimal("6"))
        self.assertEqual(sum(item["duration_seconds"] for item in self.view.draft_items), 3600)

        with patch.object(self.view, "_ask_full_batch_totals", return_value=None):
            self.assertFalse(self.view._resolve_full_batch_weights())
        self.view.calculation_mode_var.set("per_piece")
        self.view._update_calculation_form()
        self.view.draft_items.clear()
        self.view._refresh_draft()


        self.view.item_vars["element_name"].set("Wspornik")
        self.view.item_vars["used_weight_kg"].set("1")
        self.view.operation_var.set("Gięcie")
        self.view.add_item()
        self.assertEqual(self.view.draft_items[0]["operation"], "bending")
        self.view.draft_tree.selection_set("0")
        self.view.edit_draft_item()
        self.assertEqual(self.view.operation_var.get(), "Gięcie")

        self.view.photo_width_scale.set(30)
        self.view._on_photo_width_change()
        self.assertEqual(self.view.settings["photo_width_mm"], "30")
        self.assertEqual(self.view.photo_width_label_var.get(), "30 mm")
        self.view._save_photo_width()
        self.assertEqual(self.view.storage.get_settings(self.view.user_id)["photo_width_mm"], "30")

        self.view.wz_row_height_scale.set(8)
        self.view._on_wz_row_height_change()
        self.assertEqual(self.view.settings["wz_row_height_mm"], "8")
        self.assertEqual(self.view.wz_row_height_label_var.get(), "8 mm")
        self.view._save_wz_row_height()
        self.assertEqual(self.view.storage.get_settings(self.view.user_id)["wz_row_height_mm"], "8")

    def test_item_preview_shows_photo_and_all_entered_parameters(self) -> None:
        from io import BytesIO

        from PIL import Image

        image_data = BytesIO()
        Image.new("RGB", (120, 80), color="steelblue").save(image_data, format="PNG")
        self.view.item_vars["element_name"].set("Wspornik")
        self.view.item_vars["material"].set("S355")
        self.view.item_vars["thickness_mm"].set("8")
        self.view.item_vars["quantity"].set("5")
        self.view.item_vars["used_weight_kg"].set("1.25")
        self.view.item_vars["price_per_kg"].set("4.70")
        self.view.item_vars["hours"].set("1")
        self.view.item_vars["minutes"].set("2")
        self.view.item_vars["seconds"].set("3")
        self.view.item_vars["burning_rate_per_hour"].set("500")
        self.view.item_vars["vat_percent"].set("23")
        self.view._set_item_photo(image_data.getvalue(), "wspornik.png")
        self.view.add_item()

        self.view.preview_draft_item(0)
        self.app.update()
        window = next(
            child for child in self.view.winfo_children() if isinstance(child, tk.Toplevel)
        )

        def walk(widget):
            for child in widget.winfo_children():
                yield child
                yield from walk(child)

        labels = [widget.cget("text") for widget in walk(window) if isinstance(widget, tk.Label)]
        for expected in (
            "Parametry elementu",
            "Wspornik",
            "S355",
            "8 mm",
            "Sztuka",
            "5 szt.",
            "1.25 kg",
            "4,70 zł/kg",
            "01:02:03",
            "500,00 zł/godz.",
            "23%",
        ):
            self.assertIn(expected, labels)
        image_canvas = next(widget for widget in walk(window) if isinstance(widget, tk.Canvas))
        self.assertTrue(image_canvas.find_withtag("all"))
        window.destroy()

    def test_saved_estimate_opens_editable_delivery_note_without_changing_offer(self) -> None:
        self.view.item_vars["element_name"].set("Detal 180x70")
        self.view.item_vars["material"].set("S355")
        self.view.item_vars["thickness_mm"].set("8")
        self.view.item_vars["quantity"].set("5")
        self.view.item_vars["used_weight_kg"].set("1")
        self.view.add_item()
        self.view.customer_var.set("KADAM")
        self.view.order_number_var.set("012/010/2026")
        self.view.save_estimate()

        self.view._show_page("history")
        self.view.history_tree.selection_set(str(self.view.editing_estimate_id))
        self.view.navigation_buttons["delivery_note"].invoke()
        self.app.update()

        self.assertEqual(self.view.current_page, "delivery_note")
        self.assertEqual(self.view.navigation_buttons["delivery_note"].cget("text"), "▣   Generuj WZ")
        def walk(widget):
            for child in widget.winfo_children():
                yield child
                yield from walk(child)

        delivery_entries = [
            widget for widget in walk(self.view.delivery_note_form) if isinstance(widget, ttk.Entry)
        ]
        for field in ("document_number", "order_number"):
            entry = next(
                widget
                for widget in delivery_entries
                if widget.cget("textvariable") == self.view.delivery_note_variables[field]._name
            )
            self.assertEqual(str(entry.cget("state")), "normal")
        self.assertEqual(self.view.delivery_note_variables["document_number"].get(), "WZ-012/010/2026")
        self.assertEqual(self.view.delivery_note_variables["delivery_address"].get(), "odbiór własny")
        self.assertEqual(len(self.view.delivery_note_rows), 1)
        row = self.view.delivery_note_rows[0]
        self.assertEqual(row["product"].get(), "Element cięty")
        self.assertEqual(row["description"].get(), "Detal 180x70")
        self.assertEqual(row["description2"].get(), "S355 · 8 mm")
        self.assertEqual(row["quantity"].get(), "5")
        row["quantity"].set("6")
        self.view._add_delivery_note_row({
            "product": "Element cięty",
            "description": "Element dodatkowy",
            "description2": "S235",
            "quantity": "2",
            "unit": "szt",
            "notes": "",
        })
        self.assertEqual(len(self.view.delivery_note_rows), 2)
        self.assertEqual(self.view.draft_items[0]["quantity"], 5)
        self.assertEqual(self.view._delivery_note_data()["items"][0]["quantity"], "6")
        self.assertEqual(self.view._delivery_note_data()["items"][1]["description"], "Element dodatkowy")
        self.assertEqual(
            self.view.storage.get_estimate(self.view.user_id, self.view.editing_estimate_id)["items"][0]["quantity"],
            5,
        )

        self.view._show_page("quote")
        self.view.draft_tree.selection_set("0")
        self.view.edit_draft_item()
        self.view.item_vars["quantity"].set("7")
        self.view.add_item()
        self.view.save_estimate()
        self.assertIsNone(self.view.delivery_note_estimate_id)
        self.view._open_delivery_note()
        self.assertEqual(len(self.view.delivery_note_rows), 1)
        self.assertEqual(self.view.delivery_note_rows[0]["quantity"].get(), "7")

    def test_navigation_opens_manual_wz_without_selected_or_saved_estimate(self) -> None:
        self.view._show_page("history")
        self.assertFalse(self.view.history_tree.selection())

        with patch("blachcalc.messagebox.showinfo") as showinfo:
            self.view.navigation_buttons["delivery_note"].invoke()

        self.assertEqual(self.view.current_page, "delivery_note")
        self.assertTrue(self.view.delivery_note_initialized)
        self.assertIsNone(self.view.delivery_note_estimate_id)
        self.assertFalse(showinfo.called)
        self.assertEqual(self.view.delivery_note_variables["customer_name"].get(), "")
        self.assertEqual(self.view.delivery_note_variables["order_number"].get(), "")
        self.assertEqual(self.view.delivery_note_variables["document_number"].get(), "")
        self.assertEqual(len(self.view.delivery_note_rows), 1)
        self.assertEqual(self.view.delivery_note_rows[0]["product"].get(), "")
        self.assertEqual(self.view.delivery_note_return_page, "history")

        self.view.delivery_note_variables["customer_name"].set("Nowy klient")
        self.view.delivery_note_variables["order_number"].set("RĘCZNE-01")
        self.view.delivery_note_variables["document_number"].set("WZ/01/2026")
        self.view.delivery_note_rows[0]["product"].set("Usługa CNC")
        self.view.delivery_note_rows[0]["description"].set("Element spoza wyceny")
        self.assertEqual(self.view._delivery_note_data()["document_number"], "WZ/01/2026")
        self.assertEqual(self.view._delivery_note_data()["items"][0]["description"], "Element spoza wyceny")
        from io import BytesIO

        import pymupdf

        preview: dict[str, bytes] = {}
        with patch.object(
            self.view,
            "_show_delivery_note_preview",
            side_effect=lambda _data, pdf_data: preview.setdefault("pdf", pdf_data),
        ):
            self.view._preview_delivery_note()
        document = pymupdf.open(stream=BytesIO(preview["pdf"]), filetype="pdf")
        self.assertIn("Element spoza wyceny", document[0].get_text())
        document.close()

    def test_navigation_can_start_wz_from_unsaved_quote_data(self) -> None:
        self.view.item_vars["element_name"].set("Detal z bieżącego formularza")
        self.view.item_vars["material"].set("S235")
        self.view.item_vars["thickness_mm"].set("4")
        self.view.item_vars["quantity"].set("3")
        self.view.item_vars["used_weight_kg"].set("1")
        self.view.add_item()
        self.view.customer_var.set("Klient bez zapisanej oferty")
        self.view.order_number_var.set("ROB-12")

        self.view.navigation_buttons["delivery_note"].invoke()

        self.assertEqual(self.view.current_page, "delivery_note")
        self.assertEqual(self.view.delivery_note_variables["customer_name"].get(), "Klient bez zapisanej oferty")
        self.assertEqual(self.view.delivery_note_variables["order_number"].get(), "ROB-12")
        self.assertEqual(self.view.delivery_note_variables["document_number"].get(), "WZ-ROB-12")
        self.assertEqual(len(self.view.delivery_note_rows), 1)
        self.assertEqual(
            self.view.delivery_note_rows[0]["description"].get(),
            "Detal z bieżącego formularza",
        )
        self.assertEqual(self.view.delivery_note_return_page, "quote")

    def test_delivery_note_product_reflects_quote_operation(self) -> None:
        base_item = {
            "element_name": "Wspornik",
            "material": "S235JR",
            "thickness_mm": "4",
        }

        for operation, expected_product in (
            ("cutting", "Element cięty"),
            ("bending", "Element gięty"),
            ("cutting_bending", "Element cięty + gięty"),
        ):
            with self.subTest(operation=operation):
                row = self.view._delivery_note_item_from_quote({
                    **base_item,
                    "operation": operation,
                })
                self.assertEqual(row["product"], expected_product)

    def test_delivery_note_labels_remain_centered_over_responsive_inputs(self) -> None:
        self.view.navigation_buttons["delivery_note"].invoke()
        self.app.update_idletasks()
        self.app.update()

        product_widths = []
        for width in (800, 1000, 1200):
            self.app.geometry(f"{width}x900+20+20")
            self.app.update_idletasks()
            self.app.update()
            row = self.view.delivery_note_rows[0]["frame"]
            product_widths.append(row.winfo_children()[0].winfo_width())
            for key, label, entry in zip(
                ("product", "description", "description2", "quantity", "unit", "notes"),
                self.view.delivery_note_header_labels,
                row.winfo_children()[:6],
            ):
                label_center = label.winfo_rootx() + label.winfo_width() / 2
                entry_center = entry.winfo_rootx() + entry.winfo_width() / 2
                with self.subTest(window_width=width, column=key):
                    self.assertLessEqual(abs(label_center - entry_center), 1)
        self.assertLess(product_widths[0], product_widths[-1])

    def test_delivery_note_preview_precedes_save_to_dedicated_folder(self) -> None:
        from io import BytesIO

        import pymupdf

        self.view.delivery_note_variables["document_number"].set("WZ-TEST")
        self.view.delivery_note_variables["date"].set("23.10.2026")
        self.view.delivery_note_variables["customer_name"].set("Klient")
        self.view.delivery_note_variables["order_number"].set("TEST")
        self.view.delivery_note_variables["delivery_address"].set("odbiór własny")
        self.view._add_delivery_note_row({
            "product": "Element cięty",
            "description": "Detal testowy",
            "description2": "S355 · 8 mm",
            "quantity": "2",
            "unit": "szt",
            "notes": "",
        })
        preview_data: dict[str, object] = {}

        def capture_preview(data, pdf_data: bytes) -> None:
            preview_data["data"] = data
            preview_data["pdf_data"] = pdf_data

        with patch.object(self.view, "_show_delivery_note_preview", side_effect=capture_preview):
            self.view._preview_delivery_note()

        self.assertIn("data", preview_data)
        generated_pdf = pymupdf.open(
            stream=BytesIO(preview_data["pdf_data"]),
            filetype="pdf",
        )
        self.assertIn("Detal testowy", generated_pdf[0].get_text())
        generated_pdf.close()
        self.view._show_delivery_note_preview(
            preview_data["data"],
            preview_data["pdf_data"],
        )
        self.app.update()
        self.assertEqual(self.view.current_page, "pdf_preview")
        self.assertTrue(self.view._pdf_preview_images)
        self.view.pdf_preview_back_button.invoke()
        self.app.update()
        self.assertEqual(self.view.current_page, "delivery_note")

        with tempfile.TemporaryDirectory() as directory:
            wz_directory = Path(directory) / "BLACHCALC" / "WZ"
            excel_directory = Path(directory) / "BLACHCALC" / "EXCEL"
            daily_directory = wz_directory / date.today().strftime("%d.%m")
            target = daily_directory / "WZ-TEST_Klient.S.C"
            with (
                patch("dashboard_documents.filedialog.asksaveasfilename", return_value=str(target)) as save_dialog,
                patch("blachcalc.messagebox.showinfo"),
            ):
                self.view.settings["wz_export_directory"] = str(wz_directory)
                self.view.settings["excel_export_directory"] = str(excel_directory)
                self.view._save_delivery_note_pdf(preview_data["data"])
                target = Path(str(target) + ".pdf")
                self.assertTrue(target.is_file())
                excel_file = excel_directory / date.today().strftime("%d.%m") / "WZ-TEST_Klient.S.C.xlsx"
                self.assertTrue(excel_file.is_file())
                self.assertEqual(Path(save_dialog.call_args.kwargs["initialdir"]), daily_directory)
                saved_pdf = pymupdf.open(target)
                self.assertIn("Detal testowy", saved_pdf[0].get_text())
                saved_pdf.close()

    def test_offer_exports_use_a_daily_subfolder(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            export_root = Path(directory) / "BLACHCALC" / "OFERTY"
            expected_directory = export_root / date.today().strftime("%d.%m")
            with patch("dashboard_quote.filedialog.asksaveasfilename", return_value="") as save_dialog:
                self.view.settings["offer_export_directory"] = str(export_root)
                self.assertEqual(self.view._export_target("pdf", "OF-TEST.pdf"), "")
            self.assertTrue(expected_directory.is_dir())
            self.assertEqual(
                Path(save_dialog.call_args.kwargs["initialdir"]),
                expected_directory,
            )

    def test_saving_offer_pdf_also_saves_excel_in_dated_excel_folder(self) -> None:
        estimate = {
            "header": {
                "quote_number": "OF_Z-10_Firma",
                "customer_name": "Firma",
                "order_number": "Z-10",
                "created_at": datetime.now().astimezone().isoformat(timespec="seconds"),
                "net_total": "32.33", "vat_amount": "7.44", "gross_total": "39.77",
            },
            "items": [{
                "element_name": "Wspornik", "material": "S235JR", "thickness_mm": "4",
                "quantity": 1, "price_per_kg": "12", "used_weight_kg": "2",
                "duration_seconds": 60, "burning_rate_per_hour": "500", "vat_percent": "23",
                "material_cost": "24.00", "burning_cost": "8.33", "unit_net": "32.33",
                "unit_vat": "7.44", "unit_gross": "39.77", "line_net": "32.33",
                "line_vat": "7.44", "line_gross": "39.77",
            }],
        }
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory) / "BLACHCALC" / "OFERTY"
            day = date.today().strftime("%d.%m")
            pdf_path = root / day / "OF_Z-10_Firma.pdf"
            with (
                patch("dashboard_quote.filedialog.asksaveasfilename", return_value=str(pdf_path)),
                patch("dashboard_quote.messagebox.showinfo") as info,
            ):
                self.view.settings["offer_export_directory"] = str(root)
                self.view.settings["excel_export_directory"] = str(root.parent / "EXCEL")
                self.view._write_estimate_pdf(estimate, "offer")
            self.assertTrue(pdf_path.is_file())
            self.assertTrue((root.parent / "EXCEL" / day / "OF_Z-10_Firma.xlsx").is_file())
            self.assertIn("Excel", info.call_args.args[1])

    def test_delivery_note_draft_is_persisted_and_restored(self) -> None:
        self.view.navigation_buttons["delivery_note"].invoke()
        self.view.delivery_note_variables["document_number"].set("WZ-ROB-9")
        self.view.delivery_note_variables["customer_name"].set("Klient roboczy")
        self.view.issued_packages_text.insert("1.0", "Paleta EUR")
        self.view.delivery_note_rows[0]["description"].set("Detal do wznowienia")
        self.view._add_delivery_note_row({
            "product": "Usługa",
            "description": "Pozycja druga",
            "description2": "",
            "quantity": "3",
            "unit": "szt",
            "notes": "Kontrola",
        })
        self.assertTrue(self.view.save_delivery_note_draft())

        self._clear_delivery_note_form()
        self.view.settings = self.storage.get_settings(self.user_id)
        self.view._restore_delivery_note_draft()
        self.assertTrue(self.view.delivery_note_initialized)
        self.assertEqual(
            self.view.delivery_note_variables["document_number"].get(),
            "WZ-ROB-9",
        )
        self.assertEqual(
            self.view.issued_packages_text.get("1.0", "end-1c"),
            "Paleta EUR",
        )
        self.assertEqual(len(self.view.delivery_note_rows), 2)
        self.assertEqual(
            self.view.delivery_note_rows[0]["description"].get(),
            "Detal do wznowienia",
        )
        self.assertEqual(
            self.view.delivery_note_rows[1]["notes"].get(),
            "Kontrola",
        )

    def test_settings_window_is_resizable_and_grouped(self) -> None:
        self.view.open_settings()
        self.app.update()
        dialog = next(
            window
            for window in self.view.winfo_children()
            if isinstance(window, tk.Toplevel)
        )
        self.assertEqual(dialog.resizable()[0], 1)
        notebook = next(
            widget for widget in self._walk_widgets(dialog)
            if isinstance(widget, ttk.Notebook)
        )
        self.assertEqual(
            [notebook.tab(tab, "text") for tab in notebook.tabs()],
            ["Firma", "Wycena", "Dokumenty", "Wygląd", "Aplikacja"],
        )
        self.assertTrue(dialog.state() in {"zoomed", "normal"})
        for tab in notebook.tabs():
            contents = self._walk_widgets(notebook.nametowidget(tab))
            self.assertTrue(any(isinstance(widget, tk.Canvas) for widget in contents))
            self.assertTrue(any(isinstance(widget, ttk.Scrollbar) for widget in contents))
        appearance_tab = notebook.tabs()[3]
        appearance_widgets = self._walk_widgets(notebook.nametowidget(appearance_tab))
        appearance_notebook = next(
            widget for widget in appearance_widgets if isinstance(widget, ttk.Notebook)
        )
        self.assertEqual(
            [
                appearance_notebook.tab(tab, "text")
                for tab in appearance_notebook.tabs()
            ],
            ["Jasny motyw", "Ciemny motyw"],
        )
        self.assertTrue(any(
            isinstance(widget, ttk.Button)
            and widget.cget("text") == "Przywróć domyślne palety"
            for widget in self._walk_widgets(notebook.nametowidget(appearance_tab))
        ))
        preview_button = next(
            widget for widget in appearance_widgets
            if isinstance(widget, tk.Label) and widget.cget("text") == " ＋ Dodaj pozycję "
        )
        self.assertEqual(preview_button.cget("bg").upper(), "#173B63")
        appearance_notebook.select(appearance_notebook.tabs()[1])
        self.app.update()
        self.assertEqual(preview_button.cget("bg").upper(), "#4C93E6")
        app_tab = notebook.tabs()[-1]
        notebook.select(app_tab)
        self.app.update()
        tab_widgets = self._walk_widgets(notebook.nametowidget(app_tab))
        buttons = [
            widget.cget("text")
            for widget in tab_widgets
            if isinstance(widget, ttk.Button)
        ]
        self.assertIn("⟳  Aktualizuj aplikację", buttons)
        self.assertIn("Uruchom testy aplikacji…", buttons)
        for location in (
            "Domyślny folder zdjęć",
            "Oferty PDF",
            "Dokumenty WZ",
            "Pliki Excel",
            "Tymczasowe pliki drukowania",
            "Baza danych i kopie",
        ):
            self.assertTrue(any(
                isinstance(widget, tk.Label) and widget.cget("text") == location
                for widget in self._walk_widgets(notebook.nametowidget(app_tab))
            ))
        self.assertFalse(any(
            isinstance(widget, ttk.Checkbutton)
            and widget.cget("text") == "Używaj ciemnego motywu"
            for widget in self._walk_widgets(dialog)
        ))
        dialog.destroy()

    def test_settings_save_default_photo_folder(self) -> None:
        with tempfile.TemporaryDirectory() as temporary_directory:
            gallery_directory = Path(temporary_directory) / "Galeria"
            gallery_directory.mkdir()
            self.view.open_settings()
            self.app.update()
            dialog = next(
                window
                for window in self.view.winfo_children()
                if isinstance(window, tk.Toplevel)
            )
            photo_directory_entry = next(
                widget
                for widget in self._walk_widgets(dialog)
                if isinstance(widget, ttk.Entry)
                and widget.get() == self.storage.get_settings(self.user_id)["item_photo_directory"]
            )
            photo_directory_entry.delete(0, "end")
            photo_directory_entry.insert(0, str(gallery_directory))
            next(
                widget
                for widget in self._walk_widgets(dialog)
                if isinstance(widget, ttk.Button)
                and widget.cget("text") == "Zapisz ustawienia"
            ).invoke()
            self.app.update()

            self.assertEqual(
                self.storage.get_settings(self.user_id)["item_photo_directory"],
                str(gallery_directory),
            )

    def test_settings_fields_offer_individual_default_buttons(self) -> None:
        from storage import DEFAULT_SETTINGS

        self.view.open_settings()
        self.app.update()
        dialog = next(
            window
            for window in self.view.winfo_children()
            if isinstance(window, tk.Toplevel)
        )
        notebook = next(
            widget
            for widget in self._walk_widgets(dialog)
            if isinstance(widget, ttk.Notebook)
        )
        company_tab = notebook.nametowidget(notebook.tabs()[0])
        company_entry = next(
            widget
            for widget in self._walk_widgets(company_tab)
            if isinstance(widget, ttk.Entry)
            and widget.get() == DEFAULT_SETTINGS["company_name"]
        )
        row = company_entry.grid_info()["row"]
        company_entry.delete(0, "end")
        company_entry.insert(0, "Niestandardowa firma")
        next(
            widget
            for widget in self._walk_widgets(company_tab)
            if isinstance(widget, ttk.Button)
            and widget.cget("text") == "Domyślne"
            and widget.grid_info().get("row") == row
        ).invoke()
        self.assertEqual(company_entry.get(), DEFAULT_SETTINGS["company_name"])

        application_tab = notebook.nametowidget(notebook.tabs()[-1])
        self.assertTrue(any(
            isinstance(widget, ttk.Entry)
            and widget.get() == str(self.storage.database_path.parent.resolve())
            for widget in self._walk_widgets(application_tab)
        ))
        dialog.destroy()

    def test_control_s_saves_current_document_from_its_preview(self) -> None:
        self.view.current_page = "summary"
        with patch.object(self.view, "export_summary_pdf") as save_offer:
            self.view._shortcut_save()
        save_offer.assert_called_once_with()

        self.view.current_page = "pdf_preview"
        with patch.object(self.view, "_save_current_document_preview") as save_wz:
            self.view._shortcut_save()
        save_wz.assert_called_once_with()

    def test_print_pdf_bytes_uses_windows_print_verb_without_save_dialog(self) -> None:
        from pathlib import Path

        pdf_content = b"%PDF-test-document"
        submitted: dict[str, str] = {}

        def capture_print(filename: str, verb: str) -> None:
            submitted["filename"] = filename
            submitted["verb"] = verb

        with (
            patch("dashboard_documents.os.startfile", side_effect=capture_print, create=True),
            patch("blachcalc.messagebox.showinfo"),
        ):
            self.view._print_pdf_bytes(pdf_content, "testowa")

        print_file = Path(submitted["filename"])
        try:
            self.assertEqual(submitted["verb"], "print")
            self.assertEqual(print_file.read_bytes(), pdf_content)
            self.assertEqual(print_file.parent.name, "print_jobs")
        finally:
            print_file.unlink(missing_ok=True)

    def test_offer_and_delivery_note_have_direct_print_actions(self) -> None:
        def walk(widget):
            for child in widget.winfo_children():
                yield child
                yield from walk(child)

        self.view.open_settings()
        self.app.update()
        settings_dialog = next(
            window
            for window in self.view.winfo_children()
            if isinstance(window, tk.Toplevel)
        )
        self.assertFalse(any(
            isinstance(widget, ttk.Button) and widget.cget("text") == "⟳  Aktualizuj"
            for widget in walk(self.view)
        ))
        self.assertTrue(any(
            isinstance(widget, ttk.Button) and widget.cget("text") == "⟳  Aktualizuj aplikację"
            for widget in walk(settings_dialog)
        ))
        settings_dialog.destroy()
        self.assertTrue(any(
            isinstance(widget, ttk.Button) and widget.cget("text") == "Drukuj ofertę"
            for widget in walk(self.view.summary_tab)
        ))
        self.assertTrue(any(
            isinstance(widget, ttk.Button) and widget.cget("text") == "Drukuj WZ"
            for widget in walk(self.view.delivery_note_tab)
        ))
        self.assertTrue(any(
            isinstance(widget, ttk.Checkbutton)
            and widget.cget("text") == "Oferta dla biura — pełne parametry wyceny"
            for widget in walk(self.view.summary_tab)
        ))
        self.assertTrue(any(
            isinstance(widget, ttk.Button) and widget.cget("text") == "Drukuj obie oferty"
            for widget in walk(self.view.summary_tab)
        ))

    def test_summary_print_uses_office_checkbox_and_can_print_both(self) -> None:
        estimate = {"header": {"quote_number": "OF-TEST"}}
        self.view.summary_estimate = estimate

        with patch.object(self.view, "_print_estimate_pdf") as print_pdf:
            self.view.office_offer_var.set(False)
            self.view.print_summary_pdf()
            print_pdf.assert_called_once_with(estimate, "offer")

            print_pdf.reset_mock()
            self.view.office_offer_var.set(True)
            self.view.print_summary_pdf()
            print_pdf.assert_called_once_with(estimate, "office")

            print_pdf.reset_mock()
            self.view.print_both_summary_pdfs()
            print_pdf.assert_called_once_with(estimate, "both")

    def test_summary_pdf_export_uses_office_checkbox(self) -> None:
        estimate = {"header": {"quote_number": "OF-TEST"}}
        self.view.summary_estimate = estimate
        self.view.office_offer_var.set(True)

        with patch.object(self.view, "_write_estimate_pdf") as write_pdf:
            self.view.export_summary_pdf()

        write_pdf.assert_called_once_with(estimate, "office")

    def test_office_checkbox_switches_preview_title_and_row_height_slider(self) -> None:
        self.assertEqual(self.view.preview_title_var.get(), "Oferta dla klienta")
        self.assertEqual(self.view.office_controls_card.winfo_manager(), "")
        self.assertEqual(self.view.photo_width_slider_card.winfo_manager(), "pack")

        self.view.office_offer_var.set(True)
        self.app.update()
        self.assertEqual(self.view.preview_title_var.get(), "Oferta dla biura")
        self.assertEqual(self.view.office_controls_card.winfo_manager(), "pack")
        self.assertEqual(self.view.photo_width_slider_card.winfo_manager(), "")

        self.view.office_offer_var.set(False)
        self.app.update()
        self.assertEqual(self.view.preview_title_var.get(), "Oferta dla klienta")
        self.assertEqual(self.view.office_controls_card.winfo_manager(), "")
        self.assertEqual(self.view.photo_width_slider_card.winfo_manager(), "pack")

    def test_office_row_height_slider_updates_and_saves_row_height(self) -> None:
        self.view.office_row_height_scale.set(12)
        self.view._on_office_row_height_change()
        self.assertEqual(self.view.settings["office_row_height_mm"], "12")
        self.assertEqual(self.view.office_row_height_label_var.get(), "12 mm")
        self.view._save_office_row_height()
        self.assertEqual(
            self.view.storage.get_settings(self.view.user_id)["office_row_height_mm"],
            "12",
        )

    def test_office_font_scale_slider_updates_and_saves_scale(self) -> None:
        self.view.office_font_scale_scale.set(150)
        self.view._on_office_font_scale_change()
        self.assertEqual(self.view.settings["office_font_scale_percent"], "150")
        self.assertEqual(self.view.office_font_scale_label_var.get(), "150%")
        self.view._save_office_font_scale()
        self.assertEqual(
            self.view.storage.get_settings(self.view.user_id)["office_font_scale_percent"],
            "150",
        )

    def test_office_preview_renders_selected_document_kind(self) -> None:
        estimate = {"header": {"quote_number": "OF-TEST"}, "items": []}
        self.view.summary_estimate = estimate
        self.view.office_offer_var.set(True)
        rendered: dict[str, str] = {}

        def capture_export(_estimate, _settings, _destination, document_kind):
            rendered["kind"] = document_kind

        with (
            patch("dashboard_documents.export_estimate_pdf", side_effect=capture_export),
            patch.object(self.view, "_render_pdf_pages_to_canvas"),
        ):
            self.view._render_estimate_preview()

        self.assertEqual(rendered["kind"], "office")

    def test_print_offer_dialog_offers_client_office_and_combined_documents(self) -> None:
        estimate = {"header": {"quote_number": "OF-TEST"}}

        def walk(widget):
            for child in widget.winfo_children():
                yield child
                yield from walk(child)

        with patch.object(self.view, "_print_estimate_pdf") as print_pdf:
            self.view._choose_pdf_kind(estimate, print_after_export=True)
            dialog = next(
                window for window in self.view.winfo_children()
                if isinstance(window, tk.Toplevel)
            )
            widgets = list(walk(dialog))
            radio_values = {
                widget.cget("value")
                for widget in widgets
                if isinstance(widget, ttk.Radiobutton)
            }
            self.assertEqual(radio_values, {"offer", "office", "both"})
            next(
                widget for widget in widgets
                if isinstance(widget, ttk.Radiobutton) and widget.cget("value") == "both"
            ).invoke()
            next(
                widget for widget in widgets
                if isinstance(widget, ttk.Button) and widget.cget("text") == "Drukuj"
            ).invoke()

        print_pdf.assert_called_once_with(estimate, "both")

    def test_quote_form_fields_match_combined_burn_time_width(self) -> None:
        time_row = self.view.time_cell.winfo_children()[1]
        target_width = sum(child.winfo_reqwidth() for child in time_row.winfo_children())
        duration_entries = set(self.view._item_focus_chain[-3:])

        def walk(widget):
            for child in widget.winfo_children():
                if isinstance(child, (ttk.Entry, ttk.Combobox)):
                    yield child
                yield from walk(child)

        fields = [
            widget for widget in walk(self.view.item_body)
            if widget not in duration_entries
            and widget not in self.view.dimensions_entries
            and widget is not self.view.operation_combo
            and widget is not self.view.bending_price_entry
            and widget is not self.view.bending_count_entry
        ]
        self.assertGreater(len(fields), 5)
        for field in fields:
            with self.subTest(field=field):
                self.assertLessEqual(abs(field.winfo_reqwidth() - target_width), 1)

    def test_order_fields_stretch_equally_at_all_form_widths(self) -> None:
        cells = (
            self.view.customer_cell,
            self.view.order_number_entry.master,
            self.view.notes_entry.master,
        )
        for width in (700, 1100):
            self.app.geometry(f"{width}x680+20+20")
            self.app.update()
            cell_widths = [cell.winfo_width() for cell in cells]
            with self.subTest(window_width=width):
                self.assertLess(max(cell_widths) - min(cell_widths), 2)
                self.assertTrue(all(cell.winfo_width() > 150 for cell in cells))
                for cell in cells:
                    field = next(
                        child
                        for child in cell.winfo_children()
                        if isinstance(child, (ttk.Entry, ttk.Combobox))
                    )
                    self.assertEqual(field.winfo_width(), cell.winfo_width())

    def test_item_sections_reflow_symmetrically_with_form_width(self) -> None:
        details = self.view.item_details_panel
        calculation = self.view.item_calculation_panel

        self.app.geometry("1260x680+20+20")
        self.app.update()
        self.assertFalse(self.view.quote_layout_compact)
        self.assertEqual(details.grid_info()["column"], 0)
        self.assertEqual(details.grid_info()["columnspan"], 1)
        self.assertEqual(calculation.grid_info()["column"], 1)
        self.assertEqual(calculation.grid_info()["columnspan"], 1)
        self.assertEqual(details.winfo_y(), calculation.winfo_y())
        self.assertLessEqual(abs(details.winfo_width() - calculation.winfo_width()), 2)
        self.assertGreaterEqual(
            self.view.item_name_entry.winfo_width(),
            self.view.item_details_body.winfo_width() - 12,
        )

        self.app.geometry("700x680+20+20")
        self.app.update()
        self.assertTrue(self.view.quote_layout_compact)
        self.assertEqual(details.grid_info()["columnspan"], 2)
        self.assertEqual(calculation.grid_info()["columnspan"], 2)
        self.assertLess(details.winfo_y() + details.winfo_height(), calculation.winfo_y())
        self.assertLessEqual(abs(details.winfo_width() - calculation.winfo_width()), 2)
        self.assertGreaterEqual(
            self.view.item_name_entry.winfo_width(),
            self.view.item_details_body.winfo_width() - 12,
        )

    def test_rates_are_locked_and_materials_come_from_settings(self) -> None:
        for field in ("price_per_kg", "burning_rate_per_hour", "vat_percent"):
            self.assertEqual(str(self.view._field_widgets[field].cget("state")), "readonly")
        self.view.storage.save_settings(self.view.user_id, {"materials": "S235\nDC01"})
        self.view.settings = self.view.storage.get_settings(self.view.user_id)
        self.view._refresh_material_choices()
        self.assertEqual(list(self.view.material_combo.cget("values")), ["S235", "DC01"])
        self.assertEqual(str(self.view.material_combo.cget("state")), "readonly")

    def test_wheel_scrolls_offer_preview(self) -> None:
        self._add_items(2)
        self.view.customer_var.set("Firma Testowa")
        self.view.order_number_var.set("Z-1")
        self.view.save_estimate()
        self.app.update()
        self.view._render_estimate_preview()
        self.app.update()
        canvas = self.view.preview_canvas
        self.assertLess(canvas.yview()[1], 1.0)
        self._wheel(canvas)
        self.assertGreater(canvas.yview()[0], 0.0)

    def test_invalid_field_is_highlighted_and_cleared_after_edit(self) -> None:
        with patch("blachcalc.messagebox.showerror") as show_error:
            self.view.add_item()
        show_error.assert_called_once()
        entry = self.view._field_widgets["element_name"]
        self.assertEqual(str(entry.cget("style")), "Invalid.TEntry")
        self.view.item_vars["element_name"].set("Wspornik")
        self.assertEqual(str(entry.cget("style")), "TEntry")

        self.view.item_vars["quantity"].set("abc")
        with patch("blachcalc.messagebox.showerror"):
            self.view.add_item()
        self.assertEqual(str(self.view._field_widgets["quantity"].cget("style")), "Invalid.TEntry")

    def test_missing_customer_is_highlighted_on_save(self) -> None:
        self._add_items(1)
        with patch("blachcalc.messagebox.showerror") as show_error:
            self.view.save_estimate()
        self.assertIn("zleceniodawc", show_error.call_args.args[1])
        self.assertEqual(
            str(self.view._field_widgets["customer"].cget("style")),
            "Invalid.TCombobox",
        )

    def test_keyboard_shortcuts_switch_pages_and_duplicate_summary(self) -> None:
        self.view.customer_combo.focus_force()
        self.app.update()
        self.view.customer_combo.event_generate("<Control-Key-3>")
        self.app.update()
        self.assertEqual(self.view.current_page, "customers")
        self.view.customer_combo.focus_force()
        self.app.update()
        self.view.customer_combo.event_generate("<Control-Key-2>")
        self.app.update()
        self.assertEqual(self.view.current_page, "history")

        self._add_items(1)
        self.view.customer_var.set("Firma")
        self.view.order_number_var.set("Z-2")
        self.view.save_estimate()
        self.assertEqual(self.view.current_page, "summary")
        self.view.preview_canvas.focus_force()
        self.app.update()
        self.view.preview_canvas.event_generate("<Control-Shift-D>")
        self.app.update()
        self.assertEqual(self.view.current_page, "quote")
        self.assertIsNone(self.view.editing_estimate_id)
        self.assertEqual(self.view.order_number_var.get(), "")
        self.assertEqual(len(self.view.draft_items), 1)


if __name__ == "__main__":
    unittest.main()
