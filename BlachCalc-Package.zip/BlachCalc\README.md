# BlachCalc | Izo-Technika

Pełna instrukcja obsługi: [INSTRUKCJA-URUCHOMIENIA.txt](./INSTRUKCJA-URUCHOMIENIA.txt).

BlachCalc to polskojęzyczna aplikacja desktopowa na Windows (Python, Tkinter,
ReportLab) do wycen cięcia laserem blach. Tworzy oferty handlowe w PDF z logo
Izo-Technika, prowadzi kartotekę klientów, historię wycen i przyjmuje feedback.
Dane klientów i wycen są przechowywane lokalnie w SQLite, a zgłoszenia feedbacku
w pliku Excel `Dokumenty\BLACHCALC\FEEDBACK\FEEDBACK.xlsx`. Domyślnie zainstalowana
aplikacja porównuje lokalne repozytorium z manifestem plików użytym przy
budowaniu. Po wykryciu zmian pyta o zgodę na przebudowanie i instalację.
Po uruchomieniu pokazuje menu z dostępem do nowej wyceny, ustawień okna i
informacji o aplikacji.

- [Dla testera — szybki start](#dla-testera--szybki-start)
- [Instalacja](#instalacja)
- [Odinstalowanie](#odinstalowanie)
- [Jak korzystać](#jak-korzystać)
- [Ustawienia](#ustawienia)
- [Oferta PDF](#oferta-pdf)
- [Gdzie są dane](#gdzie-są-dane)
- [Lista kontrolna testów](#lista-kontrolna-testów)
- [Rozwiązywanie problemów](#rozwiązywanie-problemów)
- [Dla programistów](#dla-programistów)

## Dla testera — szybki start

1. Poproś autora o gotowy plik `BlachCalc-Setup.exe` i skopiuj go na komputer,
   na którym ma być zainstalowany program.
2. Kliknij plik dwukrotnie i przejdź przez kreator. Zostaw domyślne ustawienia
   lub wybierz, czy utworzyć ikonę na pulpicie.
3. Zakończ instalację. BlachCalc można uruchomić z menu Start, ikony na
   pulpicie lub bezpośrednio z ostatniej strony kreatora.
4. Przejdź scenariusz z sekcji [Lista kontrolna testów](#lista-kontrolna-testów).

Na komputerze docelowym nie trzeba instalować Pythona ani Inno Setup,
rozpakowywać archiwum ani uruchamiać plików `.bat` lub `.ps1`. Instalacja nie
wymaga uprawnień administratora.

## Instalacja

### Wymagania

- Windows 10 lub nowszy (64-bit),
- ok. 200 MB wolnego miejsca,
- brak wymaganych uprawnień administratora.

### Kroki

1. Skopiuj otrzymany od autora plik `BlachCalc-Setup.exe` na komputer.
2. Kliknij go dwukrotnie. W kreatorze zaakceptuj domyślny folder i wybierz,
   czy ma powstać skrót na pulpicie. Zapoznaj się z licencją własnościową
   wyświetloną w kreatorze i zaakceptuj jej warunki.
3. Kliknij **Zainstaluj**, a po zakończeniu **Zakończ**. Program znajdziesz
   w menu Start; kreator może też od razu go uruchomić.

Nie rozpakowuj instalatora. Na komputerze docelowym nie są potrzebne Python,
Inno Setup ani uprawnienia administratora.

Uruchomienie nowszego instalatora aktualizuje program. Jeśli BlachCalc jest
otwarty, instalator poprosi o jego zamknięcie. Baza danych, ustawienia i oferty
pozostają w osobnych folderach danych i nie są usuwane przy aktualizacji ani
odinstalowaniu.

### Windows SmartScreen i antywirus

Wydanie niepodpisane certyfikatem może nadal wywołać ostrzeżenie SmartScreen
lub fałszywy alarm antywirusa — nowy instalator nie gwarantuje, że każdy
produkt zabezpieczający zaakceptuje program. Nie wyłączaj ochrony i nie dodawaj
ogólnych wyjątków. Jeśli plik został zablokowany, nie uruchamiaj go; przekaż
informację o wykryciu autorowi aplikacji, aby próbka mogła zostać zgłoszona do
producenta antywirusa.

Najlepszym sposobem ograniczania ostrzeżeń w publicznych wydaniach jest
podpisanie aplikacji i instalatora zaufanym certyfikatem do podpisywania kodu
oraz zgłaszanie fałszywych alarmów do odpowiednich producentów. Podpis pomaga
zweryfikować wydawcę, ale sam w sobie nie gwarantuje braku ostrzeżeń.

## Odinstalowanie

Odinstaluj BlachCalc w **Ustawienia → Aplikacje → Zainstalowane aplikacje**
albo z folderu BlachCalc w menu Start. Usuwany jest program, skróty i wpis
deinstalatora. **Baza danych i wyeksportowane oferty zostają** (patrz
[Gdzie są dane](#gdzie-są-dane)); aby usunąć wszystko, skasuj ręcznie folder
`%LOCALAPPDATA%\BlachCalc` i folder `Dokumenty\BLACHCALC` (podfoldery `OFERTY`, `WZ`, `EXCEL` tworzą się automatycznie przy starcie).

## Jak korzystać

Po lewej jest stałe menu: **Nowa wycena**, **Historia wycen**, **Kartoteka
klientów** i **Podsumowanie oferty**. Bieżące zamówienie jest stale widoczne
w lewym panelu (klient, numer zamówienia, pozycje, suma brutto).

Przycisk **Feedback** jest dostępny z menu startowego i górnego paska aplikacji.
Wpisz imię i nazwisko, opcjonalny e-mail oraz opis; zgłoszenie zapisze się
w lokalnym arkuszu Excel, po czym otworzy się szkic wiadomości do autora.
Starsze zgłoszenia z SQLite są przy uruchomieniu przenoszone do tego pliku;
tabela jest usuwana z bazy dopiero po udanym przeniesieniu.

### Nowa wycena

1. Wybierz zleceniodawcę z listy (lub dodaj nowego w kartotece) i wpisz numer
   zamówienia.
2. Dla każdej pozycji uzupełnij kolejno (pola układają się w tej kolejności):
   1. **Nazwa elementu** oraz opcjonalnie **zdjęcie** z podglądem,
   2. **Materiał** (wybór z biblioteki w Ustawieniach), **grubość**, **ilość**,
   3. **Masa**, **czas palenia**, **cena materiału**,
   4. **Stawka palenia** i **VAT** (pola tylko do odczytu — zmiana w Ustawieniach).
   Wybierz też operację: **Cięcie**, **Gięcie** lub **Cięcie + gięcie**.
   Dla dwóch ostatnich pojawi się pole **Gięcia na 1 szt.**; każde gięcie
   dolicza **cenę gięcia** (domyślnie 3,00 zł netto; zmienisz ją w
   Ustawieniach → Wycena), a opłata jest mnożona przez ilość elementów.
3. Opcjonalnie wpisz **wymiary** elementu oraz zaznacz **Otwory** i podaj ich
   średnice fi po przecinku (np. `10, 12`). Trafiają do drugiej kolumny oferty
   pod nazwą detalu i operacją.
4. Wybierz sposób liczenia (wybór jest zapamiętywany przy kolejnych elementach):
   - **Sztuka** — wpisujesz masę i czas jednej sztuki, koszt jest mnożony
     przez ilość. Masa sztuki pojawia się w tabeli oferty.
   - **Partia** — wpisujesz łączną masę i czas wszystkich sztuk; ilość to
     liczba gotowych wyrobów i nie mnoży kosztu.
   - **Pełna partia** — dodajesz dowolnie wiele elementów bez masy i czasu.
     Masę oraz czas palenia całej partii wpisujesz raz, po **Zatwierdź
     wycenę**, przed podglądem; są dzielone proporcjonalnie do ilości sztuk.
5. **Enter** przechodzi do następnego pola; Enter w ostatnim polu dodaje
   pozycję. Pozycje można edytować (prawy przycisk) i usuwać (**Delete**).
   Podczas edycji można zapisać zmiany do wybranej pozycji albo dodać osobną
   nową pozycję na podstawie zmodyfikowanych danych.
6. **Zatwierdź wycenę** zapisuje wycenę i otwiera podgląd oferty.
   Przycisk **Nowa wycena** rozpoczyna formularz od początku; przed usunięciem
   niezapisanych danych program prosi o potwierdzenie.
7. Przy uruchomieniu program porównuje pliki lokalnego repozytorium z
   manifestem zapisanym podczas budowania. Jeśli wykryje zmiany, pokazuje ich
   liczbę i pyta o zgodę; po potwierdzeniu przebudowuje aplikację, uruchamia
   instalator i otwiera program ponownie. To samo sprawdzisz w
   **Ustawienia → Aplikacja → Sprawdź aktualizacje**. Baza danych, ustawienia
   i oferty pozostają bez zmian.

Wzór: materiał = cena/kg × masa, palenie = czas × stawka/godz., netto = suma,
VAT liczony od netto. Kwoty są zaokrąglane do groszy. Domyślna stawka materiału
4,70 zł/kg uwzględnia już założoną marżę firmową; program nie dolicza do niej
drugiego, osobnego narzutu.

### Podgląd i eksport

W podglądzie (renderowanym z tego samego PDF, który trafia do pliku) można:
zapisać ofertę do PDF, wyeksportować CSV, **Drukuj ofertę** bezpośrednio przez
domyślną aplikację PDF albo wrócić do edycji. **Generuj WZ** otwiera osobny
formularz wydania zewnętrznego.
Pod przyciskami eksportu znajduje się pole **Oferta dla biura — pełne
parametry wyceny**. Zaznaczenie przełącza eksport PDF i **Drukuj ofertę** na
wersję biurową; odznaczenie wybiera ofertę klienta. **Drukuj obie oferty**
drukuje najpierw ofertę dla klienta, a następnie wersję dla biura. W ofercie
biurowej parametry oraz składowe kosztów są ujęte w tabeli przy odpowiednich
pozycjach; dokument nie dodaje osobnej strony z kalkulacją.
Podgląd zmienia się razem z zaznaczeniem. Wersja klienta pokazuje suwak
rozmiaru zdjęć, a biurowa — suwak wysokości wierszy (1–25 mm). W wersji
biurowej tabela ma zwarte opisy i mniejszą typografię pozostałych elementów;
numer oferty jest wyróżniony. Obok suwaka wysokości znajduje się skala
czcionki całego dokumentu biurowego (50–200%). Oba ustawienia są zapamiętywane;
zmiana wysokości nie wpływa na szerokości kolumn.
Można rozpocząć nowy dokument bez zapisywania wyceny i bez wybierania
zamówienia z Historii; wystarczy uzupełnić dane odbiorcy, numer zamówienia i
własne pozycje. Z otwartego formularza wyceny dane klienta i pozycje są
kopiowane jako punkt startowy, a z zapisanej oferty — tak samo jak wcześniej —
można przejść do WZ bez zmieniania jej treści. Numer dokumentu i zamówienia w
WZ można edytować. Można poprawić ilość i opisy, dodać lub usunąć pozycje,
uzupełnić adres dostawy, osoby wydającą i odbierającą oraz opakowania. Typ
opakowania można wybrać lub wpisać własny, a następnie dodać ilość; pola
pozostają edytowalne. Przycisk
**Generuj WZ** jest dostępny w nawigacji niezależnie od zaznaczenia wyceny.
Produkt w pozycji WZ jest ustawiany na podstawie operacji wybranej w wycenie:
„Element cięty”, „Element gięty” lub „Element cięty + gięty”.
Opakowanie z wyceny nie trafia do tabeli produktów WZ ani do tabeli pozycji
oferty; w WZ jest wpisywane w polu **Wydano opakowania**, a w ofercie
wspomniane dyskretnie pod podsumowaniem. Jego cena nadal wchodzi do sumy oferty.
Roboczy WZ zapisuje się automatycznie i można do niego wrócić po ponownym
uruchomieniu aplikacji; przycisk **Nowe WZ** rozpoczyna kolejny dokument.
Podgląd WZ, tak jak podgląd oferty, jest wyświetlany wewnątrz aplikacji.
Przyciski **Drukuj WZ** i **Drukuj** wysyłają pełny dokument do domyślnej
drukarki przez systemową aplikację PDF; nie trzeba wcześniej zapisywać pliku
do wybranego folderu. Windows i domyślna aplikacja PDF muszą obsługiwać
polecenie drukowania. Roboczy PDF jest przechowywany tymczasowo i usuwany
przy kolejnym uruchomieniu, jeśli ma ponad 24 godziny.
Pliki eksportu są zapisywane w podfolderze z bieżącym dniem i miesiącem
(`dd.MM`), np. `Dokumenty\BLACHCALC\OFERTY\26.10` dla ofert i
`Dokumenty\BLACHCALC\WZ\26.10` dla dokumentów WZ. Oferty mają nazwę
`OF_<numer-zamówienia>_<klient>` (z kolejnym numerem, gdy plik już istnieje).
Przy każdym zapisie PDF oferty lub WZ program od razu zapisuje też kopię
w formacie Excel (`.xlsx`) o tej samej nazwie, w folderze
`Dokumenty\BLACHCALC\EXCEL\<dd.MM>\`.
Dostępna jest też wewnętrzna karta kalkulacji z rozbiciem kosztów.

### Historia i kartoteka

- **Historia wycen** — dwuklik otwiera wycenę do edycji, **Podgląd oferty**
  pokazuje zapisany dokument, **Kopiuj do nowej** tworzy osobną kopię,
  **Usuń** kasuje po potwierdzeniu.
- **Kartoteka klientów** — nazwa, osoba kontaktowa, e-mail, telefon, NIP i
  adres (ulica, numer, kod pocztowy `00-000`, miasto, kraj). Wycena zachowuje
  kopię danych klienta z dnia zapisu.

### Skróty klawiszowe (F1 — pomoc w aplikacji)

| Skrót | Działanie |
| --- | --- |
| Ctrl+S | zapisz wycenę; na podglądzie zapisz pełny PDF, w formularzu WZ zapisz szkic |
| Ctrl+N | nowe zamówienie |
| Ctrl+P | drukuj ofertę lub WZ / eksport PDF w historii |
| Ctrl+Shift+D | kopiuj wycenę do nowej |
| Ctrl+Z / Ctrl+X | cofnij / ponów zmianę w formularzu |
| Ctrl+1…4 | Wycena, Historia, Klienci, Podsumowanie |
| F1 | pomoc |

Kółko myszy przewija obszar pod kursorem; z **Alt** przewija poziomo. Nad
edytowalnym polem liczbowym kółko zmienia jego wartość; minuty i sekundy
przechodzą między 0 a 59.

## Ustawienia

Okno ustawień otwiera się maksymalnie, dopasowuje do rozmiaru ekranu i pozwala
przewijać zawartość każdej zakładki przy mniejszym oknie. Przyciski **Zapisz
ustawienia** i **Zamknij** są umieszczone u góry. Przy konfigurowalnych polach
dostępny jest przycisk **Domyślne**; ustawienia PDF obejmują również
przywracanie warunków drugiej strony oferty.

- **Firma** — nazwa, adres, telefon, e-mail, NIP, strona, hasło marki i logo
  (PNG/GIF), wykorzystywane w nagłówku PDF.
- **Wycena** — domyślna waluta (PLN, EUR, USD lub GBP), konwerter walut
  z kursami NBP, ceny materiału i palenia, VAT, biblioteka materiałów
  (kategoria, gatunek, grubość i cena za kg) oraz ceny opakowań. Wybór
  materiału w formularzu może uzupełnić grubość i cenę. Cennik jest podany
  w wybranej walucie i nie jest zmieniany automatycznie przy jej zmianie;
  można go skorygować konwerterem.
- **Dokumenty** — ważność i warunki oferty, termin realizacji (domyślnie
  2 dni; termin jest drukowany w warunkach oferty na drugiej stronie, a nie
  jako uwaga), kolory PDF,
  szerokość zdjęć, wysokości wierszy i rozmiar tekstu; także edycja drugiej
  strony oferty, reklamacje, cennik palet, własne rubryki i kontakty.
- **Wygląd** — niezależne palety jasnego i ciemnego motywu. Można zmienić tła,
  powierzchnie, tekst, obramowania, zaznaczenia, akcenty i kolory komunikatów;
  dostępne jest też zbiorcze przywrócenie obu palet. Kolory PDF pozostają
  niezależne od kolorów interfejsu.
- **Menu główne** — Start otwiera nową wycenę. Ustawienia ekranu obejmują tryb
  okna, presety od 1K do 8K dopasowywane do dostępnego ekranu, własne wymiary,
  skalę interfejsu, centrowanie i zgodność DPI (zmiana DPI wymaga ponownego
  uruchomienia). Osobne przyciski otwierają folder aplikacji, wycen i WZ.
  „O aplikacji” pokazuje wersję, firmę, funkcje, kontakt oraz autora
  (@knowosinski) i współpracę z GitHub Copilot. Ustawienia dokumentów i
  katalogów pozostają w dotychczasowym panelu aplikacji.
- **Aplikacja** — ręczne sprawdzenie zmian w lokalnym repozytorium, folder
  galerii, oferty PDF, WZ, Excel i plików drukowania;
  lokalizacja bazy i kopii zapasowych jest widoczna i może być zmieniona.
  Istniejące pliki są przenoszone do wybranych folderów, a poprzednie kopie
  pozostają w starych lokalizacjach jako zabezpieczenie. Zmiana folderu bazy
  wymaga ponownego uruchomienia programu. Zakładka zawiera też aktualizację,
  pełne testy oraz ręczne kopie zapasowe. Testy pokazują nazwy, wyniki i
  procent postępu; korzystają z danych tymczasowych.

Motyw zmienisz ikoną księżyca/słońca w górnym pasku. Aktualizacja jest dostępna
w zakładce **Aplikacja**; przełączenie motywu ma krótkie płynne wejście.
Kopie automatyczne powstają przy starcie i przed usunięciem wyceny
(przechowywanych jest 30).

## Oferta PDF

Dwie lub więcej stron A4, zależnie od liczby pozycji i długości treści:

1. **Oferta handlowa** — dane zleceniodawcy, tabela pozycji (zdjęcie, ilość,
   masa sztuki, netto, brutto) oraz podsumowanie: razem netto, VAT, razem
   brutto. Opcjonalnie ważność, płatność i termin (puste domyślnie).
2. **Warunki** — dodatkowe warunki, odbiór i reklamacje, cennik palet,
   własne rubryki i osoby kontaktowe. Treść edytowalna w Ustawieniach.

Przy większej liczbie pozycji tabela kontynuuje się na kolejnych stronach,
powtarzając wiersz nagłówka. Każda strona zachowuje logo firmy, oznaczenie
kontynuacji, stopkę oraz numer strony z łączną liczbą stron.

Oferta używa polskich znaków w osadzonej czcionce (Arial/Segoe UI/Tahoma/DejaVu),
więc drukuje się poprawnie.

## Gdzie są dane

| Co | Gdzie |
| --- | --- |
| Baza, ustawienia, klienci, wyceny | `%LOCALAPPDATA%\BlachCalc\blachcalc.sqlite3` |
| Kopie zapasowe | `%LOCALAPPDATA%\BlachCalc\backups\` |
| Wyeksportowane oferty | `Dokumenty\BLACHCALC\OFERTY\` |
| Dokumenty WZ | `Dokumenty\BLACHCALC\WZ\` |
| Pliki Excel (oferty i WZ) | `Dokumenty\BLACHCALC\EXCEL\` |
| Zgłoszenia feedbacku | `Dokumenty\BLACHCALC\FEEDBACK\FEEDBACK.xlsx` |
| Program | `%LOCALAPPDATA%\Programs\BlachCalc\` |

Aby przenieść dane na inny komputer: Ustawienia → Utwórz kopię zapasową, a na
drugim komputerze Ustawienia → Przywróć kopię. **Kopia zawiera wszystkie dane
(klientów, ceny) — traktuj ją jak poufną.**

Logowanie jest wyłączone (`LOGIN_ENABLED = False` w `blachcalc.py`): każdy
użytkownik Windows otwiera własny lokalny profil bez hasła.

## Lista kontrolna testów

Zaznacz, co działa, a co nie — wraz z opisem i zrzutem ekranu błędu.

- [ ] Instalacja i uruchomienie z ikony na pulpicie.
- [ ] Dodanie klienta w kartotece (z poprawnym adresem i kodem pocztowym).
- [ ] Dodanie materiałów w Ustawieniach i wybór z listy w wycenie.
- [ ] Zmiana domyślnej waluty, przeliczenie kwoty i pobranie kursów NBP.
- [ ] Wycena „Sztuka” (2+ sztuki), „Partia” i „Pełna partia”, w jednym zamówieniu.
- [ ] Dodanie zdjęcia do pozycji; zmiana jego szerokości w Ustawieniach.
- [ ] Kolejność pól po Enter; Enter w ostatnim polu dodaje pozycję.
- [ ] Kółko myszy przewija obszary i zmienia liczby nad polami liczbowymi.
- [ ] Zmiana rozmiaru okna — nic się nie rozjeżdża.
- [ ] Zatwierdzenie wyceny, podgląd, zapis PDF; sprawdzenie kwot ręcznie.
- [ ] Polskie znaki (ł, ą, ę, ż…) w PDF — także po wydruku.
- [ ] Edycja drugiej strony oferty i jej odzwierciedlenie w PDF.
- [ ] Historia: edycja, kopia, usunięcie wyceny.
- [ ] Kopia zapasowa i jej przywrócenie.
- [ ] Zamknięcie i ponowne uruchomienie — dane są zachowane.
- [ ] Odinstalowanie.

## Rozwiązywanie problemów

| Problem | Rozwiązanie |
| --- | --- |
| Antywirus lub SmartScreen blokuje instalator | Nie wyłączaj ochrony ani nie dodawaj wyjątku. Zapisz nazwę wykrycia i wersję antywirusa, a następnie przekaż je autorowi do zgłoszenia fałszywego alarmu. |
| Instalator nie może zaktualizować programu | Zamknij BlachCalc i uruchom instalator ponownie. |
| Aplikacja nie startuje | Spróbuj uruchomić BlachCalc z menu Start i przekaż autorowi komunikat błędu. |
| Brak polskich liter w PDF | Aplikacja wymaga jednej z czcionek: Arial, Segoe UI, Tahoma, DejaVu. Na Windows są standardowo dostępne. |

Zgłaszając błąd podaj: wersję Windows, kroki do odtworzenia, komunikat błędu i
zrzut ekranu. Nie wysyłaj bazy danych bez zgody właściciela — zawiera dane klientów.

## Dla programistów

### Uruchamianie ze źródeł

Wymagane: Windows 10+, Python 3.10+ (z Tkinterem).

```powershell
python -m pip install -r requirements.txt
python blachcalc.py
```

### Testy

```powershell
python run_tests.py            # okienko z postępem „wykonano X z N”
python run_tests.py --no-gui   # tryb tekstowy
python -m unittest discover -p "test_*.py"
```

`Run-Tests.bat` uruchamia to samo okienko jednym kliknięciem. Okienko zamyka się
samo po udanym przebiegu, a przy błędach zostaje z listą nieudanych testów.
Aplikacja do testów okna jest uruchamiana tylko raz (`ui_harness.py`) i
współdzielona przez wszystkie testy interfejsu.

Testy okna (`test_app_ui.py`, `test_ui_*.py`) wymagają środowiska graficznego;
bez niego są pomijane.

### Budowanie paczki instalacyjnej

Te kroki wykonuje autor aplikacji na komputerze z kodem źródłowym, a nie osoba
instalująca program. Wymagane są Windows, Python 3.10+ dostępny jako `python`
w PowerShellu oraz Inno Setup 6 lub 7.

1. Zainstaluj Inno Setup 6 lub 7.
2. Otwórz PowerShell w głównym folderze projektu.
3. Uruchom:

```powershell
powershell -ExecutionPolicy Bypass -File .\Build-Windows.ps1
```

Skrypt najpierw uruchamia testy i sprawdza zależności, a następnie buduje
aplikację, instalator `release\BlachCalc-Setup.exe`, kopię instalatora
`BlachCalc-Setup.exe` w katalogu projektu oraz paczkę
`BlachCalc-Package.zip` z aktualnymi źródłami. Przekaż użytkownikowi sam
instalator — nie cały folder projektu ani folder `dist`. Na komputerze
docelowym uruchamia się wyłącznie `BlachCalc-Setup.exe`.

Jeżeli brakuje zależności, zainstaluj je jednorazowo poleceniem
`python -m pip install -r requirements-build.txt`.

Jeśli pojawi się komunikat, że nie znaleziono `ISCC.exe`, zainstaluj Inno Setup
6 lub 7 i ponownie uruchom powyższe polecenie. Nowy instalator zastępuje
poprzedni dopiero po poprawnym zbudowaniu.

Paczka projektu `BlachCalc-Package.zip` zawiera źródła i instalator
`BlachCalc-Setup.exe` bezpośrednio w głównym katalogu archiwum. Lokalne oferty
PDF i wygenerowane foldery budowania są pomijane; nie należy udostępniać ich
bez sprawdzenia, czy nie zawierają danych klientów.

Do szybkiego przebudowania i uruchomienia na komputerze deweloperskim:
`Rebuild-And-Run.bat` (lub `Rebuild-And-Run.ps1`).

Instalator i manifest źródeł buduje się poleceniem `Build-Windows.ps1`.
Zainstalowana aplikacja porównuje repozytorium, z którego powstała, z tym
manifestem. Po zgodzie użytkownika skrypt buduje instalator, który zastępuje
pliki programu i uruchamia go ponownie. Na komputerze musi być dostępne lokalne
repozytorium oraz wymagania budowania, w tym Python i Inno Setup.

### Struktura

| Plik | Zawartość |
| --- | --- |
| `blachcalc.py` | interfejs Tkinter |
| `calculator.py`, `quote_domain.py` | obliczenia i reguły kwot |
| `storage.py` | baza SQLite, ustawienia, kopie zapasowe |
| `exports.py` | eksport ofert i WZ do PDF oraz CSV |
| `offer_page.py` | edytowalna treść drugiej strony oferty |
| `app_paths.py` | ścieżki zasobów i eksportów |
| `run_tests.py`, `ui_harness.py` | runner z okienkiem postępu i wspólna aplikacja testowa |
| `test_*.py` | testy jednostkowe i okna |

### Licencja

Licencja własnościowa do użytku wyłącznie przez @knowosinski i
Izo-Technika Iłczyk Sp. Jawna — patrz `LICENSE`. Kody i pliki komponentów
zewnętrznych zachowują własne warunki wskazane w `THIRD-PARTY-NOTICES.txt`.
