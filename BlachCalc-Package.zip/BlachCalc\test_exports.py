﻿import csv
import os
import tempfile
import unittest
from decimal import Decimal
from io import BytesIO
from datetime import datetime
from pathlib import Path
from unittest.mock import patch

from exports import (
    _atomic_destination,
    _duration_label,
    _excel_cell_value,
    _safe_spreadsheet_value,
    export_delivery_note_pdf,
    office_font_scale_percent,
    pl,
    export_delivery_note_xlsx,
    export_estimate_csv,
    export_estimate_pdf,
    export_estimate_xlsx,
)
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import mm
from storage import DEFAULT_SETTINGS
from reportlab.platypus import Table as ReportLabTable
from reportlab.platypus import TableStyle as ReportLabTableStyle
from reportlab.platypus import Image as ReportLabImage
from PIL import Image as PillowImage


class ExportTests(unittest.TestCase):
    def setUp(self) -> None:
        self.estimate = {
            "header": {
                "quote_number": "OF_Z-10_Firma",
                "customer_name": "=2+2",
                "customer_tax_id": "1234567890",
                "customer_address": "Warszawa",
                "customer_email": "kontakt@example.com",
                "customer_phone": "123 456 789",
                "customer_contact_person": "Jan Kowalski",
                "order_number": "Z-10",
                "notes": "Termin: 7 dni",
                "net_total": "32.33",
                "vat_amount": "7.44",
                "gross_total": "39.77",
                "created_at": datetime.now().astimezone().isoformat(timespec="seconds"),
            },
            "items": [
                {
                    "element_name": "Wspornik",
                    "material": "S235JR",
                    "thickness_mm": "4",
                    "quantity": 1,
                    "price_per_kg": "12",
                    "used_weight_kg": "2",
                    "duration_seconds": 60,
                    "burning_rate_per_hour": "500",
                    "vat_percent": "23",
                    "material_cost": "24.00",
                    "burning_cost": "8.33",
                    "unit_net": "32.33",
                    "unit_vat": "7.44",
                    "unit_gross": "39.77",
                    "line_net": "32.33",
                    "line_vat": "7.44",
                    "line_gross": "39.77",
                }
            ],
        }

    def test_csv_uses_semicolon_bom_and_sanitizes_formula_cells(self) -> None:
        with tempfile.TemporaryDirectory() as temporary_directory:
            path = Path(temporary_directory) / "estimate.csv"
            export_estimate_csv(self.estimate, path, DEFAULT_SETTINGS)

            raw = path.read_bytes()
            self.assertTrue(raw.startswith(b"\xef\xbb\xbf"))
            with path.open(encoding="utf-8-sig", newline="") as file:
                rows = list(csv.reader(file, delimiter=";"))
            self.assertEqual(len(rows), 2)
            self.assertEqual(rows[1][rows[0].index("Zleceniodawca")], "'=2+2")
            self.assertEqual(rows[1][rows[0].index("Pozycja")], "Wspornik")
            self.assertEqual(rows[1][rows[0].index("Sprzedawca")], DEFAULT_SETTINGS["company_name"])
            self.assertEqual(rows[1][rows[0].index("NIP sprzedawcy")], "6272789387")

    def test_xlsx_has_numeric_cells_and_sanitizes_formula_cells(self) -> None:
        from openpyxl import load_workbook

        with tempfile.TemporaryDirectory() as temporary_directory:
            path = Path(temporary_directory) / "estimate.xlsx"
            export_estimate_xlsx(self.estimate, path, DEFAULT_SETTINGS)
            self.assertEqual(list(Path(temporary_directory).glob(".estimate.xlsx.*.tmp")), [])
            sheet = load_workbook(path).active

        headers = [cell.value for cell in sheet[1]]
        row = [cell.value for cell in sheet[2]]
        self.assertEqual(row[headers.index("Zleceniodawca")], "'=2+2")
        self.assertEqual(row[headers.index("Pozycja")], "Wspornik")
        self.assertEqual(row[headers.index("Wartość brutto (zł)")], 39.77)
        self.assertEqual(row[headers.index("Grubość (mm)")], 4.0)

    def test_delivery_note_xlsx_contains_header_and_items(self) -> None:
        from openpyxl import load_workbook

        note = {
            "document_number": "WZ-1",
            "customer_name": "Klient",
            "date": "2026-10-26",
            "items": [{"product": "Detal", "description": "Opis", "quantity": "3", "unit": "szt"}],
        }
        with tempfile.TemporaryDirectory() as temporary_directory:
            path = Path(temporary_directory) / "wz.xlsx"
            export_delivery_note_xlsx(note, path)
            sheet = load_workbook(path).active
            values = [[cell.value for cell in row] for row in sheet.iter_rows()]

        self.assertEqual(values[0][:2], ["Dokument WZ — Wydanie zewnętrzne", "WZ-1"])
        self.assertIn(["Lp.", "Produkt", "Opis", "Opis 2", "Ilość", "jm", "Uwagi"], values)
        self.assertEqual(values[-1][:2], [1, "Detal"])
        self.assertEqual(values[-1][4], 3.0)

    def test_csv_reports_photo_presence_without_exposing_filename(self) -> None:
        estimate = {
            **self.estimate,
            "items": [{
                **self.estimate["items"][0],
                "preview_image": b"stored locally",
                "preview_image_name": "wspornik.jpg",
            }],
        }
        with tempfile.TemporaryDirectory() as temporary_directory:
            path = Path(temporary_directory) / "with-image.csv"
            export_estimate_csv(estimate, path, DEFAULT_SETTINGS)
            with path.open(encoding="utf-8-sig", newline="") as file:
                rows = list(csv.DictReader(file, delimiter=";"))
            with path.open(encoding="utf-8-sig") as csv_file:
                self.assertNotIn("wspornik.jpg", csv_file.read())

        self.assertEqual(rows[0]["Zdjęcie poglądowe"], "Tak")

    def test_csv_failure_preserves_existing_export_and_cleans_temporary_file(self) -> None:
        with tempfile.TemporaryDirectory() as temporary_directory:
            path = Path(temporary_directory) / "estimate.csv"
            original_content = b"previous export"
            path.write_bytes(original_content)
            invalid_estimate = {
                **self.estimate,
                "items": [
                    self.estimate["items"][0],
                    {"element_name": "Incomplete item"},
                ],
            }

            with self.assertRaises(KeyError):
                export_estimate_csv(invalid_estimate, path)

            self.assertEqual(path.read_bytes(), original_content)
            self.assertEqual(list(Path(temporary_directory).glob(".estimate.csv.*.tmp")), [])

    def test_offer_pdf_includes_position_preview_images(self) -> None:
        import pymupdf

        image_buffer = BytesIO()
        PillowImage.new("RGB", (80, 50), color=(30, 80, 140)).save(image_buffer, format="JPEG")
        estimate = {
            **self.estimate,
            "items": [{
                **self.estimate["items"][0],
                "preview_image": image_buffer.getvalue(),
                "preview_image_name": "wspornik.jpg",
            }],
        }

        captured_tables = []

        def capture_table(data, *args, **kwargs):
            captured_tables.append(data)
            return ReportLabTable(data, *args, **kwargs)

        with tempfile.TemporaryDirectory() as temporary_directory:
            path = Path(temporary_directory) / "offer-with-image.pdf"
            with patch("reportlab.platypus.Table", side_effect=capture_table):
                export_estimate_pdf(estimate, DEFAULT_SETTINGS, path, "offer")
            pdf = path.read_bytes()

        self.assertTrue(pdf.startswith(b"%PDF-"))
        self.assertIn(b"/Subtype /Image", pdf)
        self.assertNotIn(b"wspornik.jpg", pdf)
        document = pymupdf.open(stream=pdf, filetype="pdf")
        self.assertGreaterEqual(document.page_count, 2)
        self.assertTrue(all(document[index].get_images(full=True) for index in range(2)))
        document.close()
        offer_table = next(
            table for table in captured_tables
            if len(table[0]) == 7
            and getattr(table[0][2], "getPlainText", lambda: "")() == "Zdjęcie"
        )
        self.assertIsInstance(offer_table[1][2], ReportLabImage)
        self.assertEqual(offer_table[1][3], "1")
        for header in offer_table[0]:
            self.assertEqual(header.style.textColor.hexval(), "0xffffff")

    def test_offer_pdf_can_be_rendered_from_memory_for_exact_preview(self) -> None:
        import pymupdf

        output = BytesIO()
        export_estimate_pdf(self.estimate, DEFAULT_SETTINGS, output, "offer")
        document = pymupdf.open(stream=output.getvalue(), filetype="pdf")

        self.assertGreaterEqual(document.page_count, 2)
        page = document[0]
        self.assertEqual(round(page.rect.width), round(A4[0]))
        self.assertGreater(page.get_pixmap().width, 0)
        document.close()

    def test_pdf_uses_only_embedded_fonts_with_polish_letters(self) -> None:
        import pymupdf

        for kind in ("offer", "internal"):
            output = BytesIO()
            export_estimate_pdf(self.estimate, DEFAULT_SETTINGS, output, kind)
            document = pymupdf.open(stream=output.getvalue(), filetype="pdf")
            for page in document:
                for block in page.get_text("dict")["blocks"]:
                    for line in block.get("lines", []):
                        for span in line["spans"]:
                            self.assertNotIn("Helvetica", span["font"], f"{kind}: {span['text']!r}")
                            self.assertNotIn("\ufffd", span["text"])
            document.close()

    def test_photo_width_setting_is_clamped_and_resizes_column(self) -> None:
        from exports import photo_width_mm

        self.assertEqual(photo_width_mm({}), 44)
        self.assertEqual(photo_width_mm({"photo_width_mm": "30,5"}), 30.5)
        self.assertEqual(photo_width_mm({"photo_width_mm": "500"}), 56)
        self.assertEqual(photo_width_mm({"photo_width_mm": "x"}), 44)
        buffer = BytesIO()
        PillowImage.new("RGB", (80, 50), color=(30, 80, 140)).save(buffer, format="JPEG")
        estimate = {**self.estimate, "items": [{**self.estimate["items"][0], "preview_image": buffer.getvalue()}]}
        captured = []

        def capture_table(data, *args, **kwargs):
            captured.append(data)
            return ReportLabTable(data, *args, **kwargs)

        with patch("reportlab.platypus.Table", side_effect=capture_table):
            export_estimate_pdf(estimate, {**DEFAULT_SETTINGS, "photo_width_mm": "30"}, BytesIO(), "offer")
        offer_table = next(
            t for t in captured
            if len(t[0]) == 7 and getattr(t[0][2], "getPlainText", lambda: "")() == "Zdjęcie"
        )
        self.assertAlmostEqual(offer_table[1][2].drawWidth / mm, 30, places=1)

    def test_offer_page_two_uses_custom_content_from_settings(self) -> None:
        import json

        import pymupdf
        from offer_page import default_offer_page, parse_offer_page, serialize_offer_page

        page = default_offer_page()
        page["terms"]["title"] = "ZXTITLE"
        page["terms"]["items"] = ["ZXPUNKT jeden", "ZXPUNKT dwa"]
        page["pallets"]["items"] = []
        page["contact"]["person"] = "ZXOSOBA"
        page["contacts"][0]["person"] = "ZXOSOBA"
        settings = {**DEFAULT_SETTINGS, "offer_page2": serialize_offer_page(page)}
        output = BytesIO()
        export_estimate_pdf(self.estimate, settings, output, "offer")
        document = pymupdf.open(stream=output.getvalue(), filetype="pdf")
        text = " ".join(document[-1].get_text().split())
        document.close()
        for expected in ("ZXTITLE", "ZXPUNKT jeden", "ZXPUNKT dwa", "ZXOSOBA"):
            self.assertIn(expected, text)
        self.assertNotIn("Cennik palet", text)
        self.assertNotIn("Nie zapewniamy", text)
        self.assertEqual(serialize_offer_page(default_offer_page()), "")
        self.assertEqual(parse_offer_page("{zepsute"), default_offer_page())
        self.assertEqual(parse_offer_page(json.dumps({"terms": 5})), default_offer_page())

    def test_offer_page_supports_custom_sections_and_multiple_contacts(self) -> None:
        import json
        import pymupdf

        from offer_page import default_offer_page, parse_offer_page, serialize_offer_page

        page = default_offer_page()
        page["custom_sections"] = [
            {"title": "Zakres dodatkowy", "text": "Pierwsza linia\nDruga linia"},
        ]
        page["contacts"] = [
            {"person": "Anna Nowak", "phone": "111", "email": "anna@example.com"},
            {"person": "Jan Kowalski", "phone": "222", "email": "jan@example.com"},
        ]
        settings = {**DEFAULT_SETTINGS, "offer_page2": serialize_offer_page(page)}
        output = BytesIO()
        export_estimate_pdf(self.estimate, settings, output, "offer")
        document = pymupdf.open(stream=output.getvalue(), filetype="pdf")
        text = " ".join(" ".join(document[index].get_text() for index in range(document.page_count)).split())
        document.close()

        for expected in (
            "Zakres dodatkowy",
            "Pierwsza linia",
            "Druga linia",
            "Anna Nowak",
            "111",
            "anna@example.com",
            "Jan Kowalski",
            "222",
            "jan@example.com",
        ):
            with self.subTest(expected=expected):
                self.assertIn(expected, text)

        legacy_page = parse_offer_page(json.dumps({
            "contact": {
                "title": "Dane teleadresowe",
                "person": "Legacy Person",
                "phone": "333",
                "email": "legacy@example.com",
            },
        }))
        self.assertEqual(legacy_page["contacts"], [{
            "person": "Legacy Person",
            "phone": "333",
            "email": "legacy@example.com",
        }])

    def test_long_offer_repeats_branding_and_page_numbers_on_every_page(self) -> None:
        import pymupdf

        items = [
            {**self.estimate["items"][0], "element_name": f"Wspornik {index:02d}"}
            for index in range(1, 81)
        ]
        output = BytesIO()
        export_estimate_pdf({**self.estimate, "items": items}, DEFAULT_SETTINGS, output, "offer")
        document = pymupdf.open(stream=output.getvalue(), filetype="pdf")

        self.assertGreaterEqual(document.page_count, 4)
        for index, page in enumerate(document, start=1):
            page_text = page.get_text()
            with self.subTest(page=index):
                self.assertTrue(page.get_images(full=True), "Każda strona oferty powinna zawierać logo.")
                self.assertIn(f"Strona {index} z {document.page_count}", page_text)
                self.assertNotIn("DALSZY CIĄG OFERTY", page_text)
                if "Wspornik " in page_text:
                    self.assertIn("Element / zakres", page_text)
        document.close()

    def test_delivery_note_pdf_matches_landscape_form_and_contains_item_signatures(self) -> None:
        import pymupdf

        from exports import export_delivery_note_pdf

        note = {
            "document_number": "WZ-012/010/2026",
            "date": "13.10.2026",
            "customer_name": "KADAM",
            "customer_tax_id": "6281911936",
            "order_number": "012/010/2026",
            "delivery_address": "odbiór własny",
            "issuer": "Jan Wydający",
            "receiver": "Anna Odbierająca",
            "issued_packages": "1\n2",
            "returned_packages": "1",
            "items": [{
                "product": "Element cięty",
                "description": "Detal 180x70",
                "description2": "S355 · 8 mm",
                "quantity": "234",
                "unit": "szt",
                "notes": "Kontrola",
            }],
        }
        output = BytesIO()
        export_delivery_note_pdf(note, DEFAULT_SETTINGS, output)
        document = pymupdf.open(stream=output.getvalue(), filetype="pdf")

        self.assertEqual(document.page_count, 1)
        page = document[0]
        self.assertGreater(page.rect.width, page.rect.height)
        self.assertTrue(page.get_images(full=True))
        text = " ".join(page.get_text().split())
        self.assertEqual(text.count("Odbiorca:"), 1)
        self.assertNotIn("<b>", text)
        self.assertIn(DEFAULT_SETTINGS["company_email"], text)
        for expected in (
            "Dokument WZ - Wydanie Zewnętrzne",
            "WZ-012/010/2026",
            "012/010/2026",
            "KADAM",
            "odbiór własny",
            "Element cięty",
            "Detal 180x70",
            "S355 · 8 mm",
            "234",
            "Jan Wydający",
            "Anna Odbierająca",
            "Wydano opakowania",
            "Zdano opakowania",
            "Strona 1 z 1",
        ):
            with self.subTest(expected=expected):
                self.assertIn(expected, text)
        document.close()

    def test_delivery_note_pdf_paginates_more_than_twenty_items(self) -> None:
        import pymupdf

        from exports import export_delivery_note_pdf

        note = {
            "document_number": "WZ-Z-200",
            "date": "23.10.2026",
            "customer_name": "Firma",
            "customer_tax_id": "",
            "order_number": "Z-200",
            "delivery_address": "odbiór własny",
            "issuer": "",
            "receiver": "",
            "issued_packages": "",
            "returned_packages": "",
            "items": [
                {
                    "product": "Element cięty",
                    "description": f"Pozycja {index}",
                    "description2": "S235 · 4 mm",
                    "quantity": "1",
                    "unit": "szt",
                    "notes": "",
                }
                for index in range(1, 24)
            ],
        }
        output = BytesIO()
        export_delivery_note_pdf(note, DEFAULT_SETTINGS, output)
        document = pymupdf.open(stream=output.getvalue(), filetype="pdf")

        self.assertEqual(document.page_count, 2)
        for index, page in enumerate(document, start=1):
            with self.subTest(page=index):
                self.assertTrue(page.get_images(full=True))
                self.assertIn(f"Strona {index} z 2", page.get_text())
        text = " ".join(" ".join(page.get_text() for page in document).split())
        self.assertIn("Pozycja 1", text)
        self.assertIn("Pozycja 23", text)
        self.assertIn("Wydano opakowania", text)
        self.assertIn("Osoba wydająca", text)
        document.close()

    def test_offer_pdf_includes_terms_pallet_prices_and_contact_details(self) -> None:
        import pymupdf

        with tempfile.TemporaryDirectory() as temporary_directory:
            offer_path = Path(temporary_directory) / "offer.pdf"
            internal_path = Path(temporary_directory) / "internal.pdf"
            captured_tables = []

            def capture_table(data, *args, **kwargs):
                captured_tables.append((data, kwargs.get("colWidths")))
                return ReportLabTable(data, *args, **kwargs)

            with patch("reportlab.platypus.Table", side_effect=capture_table):
                export_estimate_pdf(self.estimate, DEFAULT_SETTINGS, offer_path, "offer")
            export_estimate_pdf(self.estimate, DEFAULT_SETTINGS, internal_path, "internal")

            offer = pymupdf.open(offer_path)
            offer_text = " ".join("\n".join(page.get_text() for page in offer).split())
            continuation_page = offer[1]
            continuation_images = continuation_page.get_images(full=True)
            continuation_colors = {
                span["color"]
                for block in continuation_page.get_text("dict")["blocks"]
                for line in block.get("lines", [])
                for span in line["spans"]
                if span["text"].strip()
            }
            offer.close()
            internal = pymupdf.open(internal_path)
            internal_text = "\n".join(page.get_text() for page in internal)
            internal.close()

        for expected_text in (
            "Dodatkowe warunki:",
            "Nie zapewniamy płaskości powierzchni",
            "Tolerancja gięcia blach wg DIN ISO 2768 – klasa c",
            "Tolerancja cięcia laserem wg PN-EN ISO 9013 – klasa 1",
            "Zapewniamy jakość wykonania po wierzchniej stronie detalu.",
            "powstających podczas cięcia laserem",
            "zniekształcenia otworów",
            "powstałych od rusztów lasera podczas cięcia.",
            "loco magazyn IZO-TECHNIKA",
            "Cennik palet:",
            "Euro",
            "Odbiór i reklamacje towaru",
            "2 dni od daty odbioru.",
            "jeden dzień od daty odbioru.",
            "Strona 1 z 2",
            "Strona 2 z 2",
            "+48 786 300 750",
            "biuro@izotechnika.com.pl",
        ):
            with self.subTest(expected_text=expected_text):
                self.assertIn(expected_text, offer_text)
        self.assertNotIn("DIN ISO 2768", internal_text)
        self.assertTrue(continuation_images)
        self.assertIn(0x18345B, continuation_colors)
        pallet_table, pallet_widths = next(
            (data, widths)
            for data, widths in captured_tables
            if data and data[0] == ["Euro – 30 zł netto,"]
        )
        self.assertEqual(
            [row[0] for row in pallet_table],
            [
                "Euro – 30 zł netto,",
                "A (1000x2000) – 90 zł netto",
                "B (1250x2500) – 180 zł netto",
                "C (1500x3000) – 200 zł netto",
            ],
        )
        self.assertEqual(sum(pallet_widths), 76 * mm)
        contact_table, _ = next(
            (data, widths)
            for data, widths in captured_tables
            if data and getattr(data[0][0], "getPlainText", lambda: "")() == "OSOBA KONTAKTOWA"
        )
        self.assertEqual(
            [cell.getPlainText() for cell in contact_table[1]],
            ["Katarzyna Iłczyk", "+48 786 300 750", "biuro@izotechnika.com.pl"],
        )
        self.assertNotIn("Biuro: Kontakt:", [getattr(row[0], "getPlainText", lambda: "")() for row in contact_table])

    def test_csv_marks_whole_order_scope_and_exports_aggregate_costs(self) -> None:
        whole_order_estimate = {
            **self.estimate,
            "items": [{
                **self.estimate["items"][0],
                "calculation_mode": "whole_order",
                "quantity": 12,
                "used_weight_kg": "4",
                "duration_seconds": 120,
                "material_cost": "48.00",
                "burning_cost": "16.67",
                "unit_net": "64.67",
                "unit_vat": "14.87",
                "unit_gross": "79.54",
                "line_net": "64.67",
                "line_vat": "14.87",
                "line_gross": "79.54",
            }],
        }
        with tempfile.TemporaryDirectory() as temporary_directory:
            path = Path(temporary_directory) / "whole-order.csv"
            export_estimate_csv(whole_order_estimate, path, DEFAULT_SETTINGS)

            with path.open(encoding="utf-8-sig", newline="") as file:
                rows = list(csv.DictReader(file, delimiter=";"))

        self.assertEqual(rows[0]["Sposób kalkulacji"], "Partia")
        self.assertEqual(rows[0]["Ilość / zakres"], "12")
        self.assertEqual(rows[0]["Materiał netto razem (zł)"], "48.00")
        self.assertEqual(rows[0]["Palenie netto razem (zł)"], "16.67")

    def test_pdf_exports_both_client_and_internal_documents(self) -> None:
        with tempfile.TemporaryDirectory() as temporary_directory:
            for document_kind in ("offer", "internal"):
                path = Path(temporary_directory) / f"{document_kind}.pdf"
                export_estimate_pdf(self.estimate, {}, path, document_kind)
                self.assertTrue(path.read_bytes().startswith(b"%PDF-"))
                self.assertGreater(path.stat().st_size, 1000)

    def test_office_offer_includes_all_calculation_parameters(self) -> None:
        import pymupdf

        estimate = {
            **self.estimate,
            "items": [{
                **self.estimate["items"][0],
                "operation": "cutting_bending",
                "dimensions": "120 x 80",
                "hole_diameters": "6, 8",
                "calculation_mode": "per_piece",
            }],
        }
        with tempfile.TemporaryDirectory() as temporary_directory:
            path = Path(temporary_directory) / "office.pdf"
            export_estimate_pdf(estimate, DEFAULT_SETTINGS, path, "office")
            with pymupdf.open(path) as document:
                self.assertEqual(len(document), 1)
                text = " ".join(document[0].get_text().split())

        for expected in (
            "OFERTA HANDLOWA",
            "WERSJA BIUROWA",
            "Oferta i parametry kalkulacji",
            "Wspornik",
            "Cięcie + gięcie",
            "S235JR",
            "120 x 80",
            "Ø6, Ø8",
            "Sztuka",
            "Cena materiału",
            "Masa / zakres",
            "Czas palenia",
            "Stawka palenia",
            "Koszt blachy",
            "Koszt palenia",
            "Kalkulacja: netto",
            "VAT",
            "Brutto",
        ):
            with self.subTest(expected=expected):
                self.assertIn(expected, text)

    def test_office_font_scale_setting_scales_table_and_quote_number_text(self) -> None:
        import pymupdf

        font_sizes: dict[int, dict[str, float]] = {}
        with tempfile.TemporaryDirectory() as temporary_directory:
            for scale in (100, 150):
                path = Path(temporary_directory) / f"office-font-{scale}.pdf"
                export_estimate_pdf(
                    self.estimate,
                    {**DEFAULT_SETTINGS, "office_font_scale_percent": str(scale)},
                    path,
                    "office",
                )
                with pymupdf.open(path) as document:
                    spans = [
                        span
                        for block in document[0].get_text("dict")["blocks"]
                        if "lines" in block
                        for line in block["lines"]
                        for span in line["spans"]
                    ]
                font_sizes[scale] = {
                    text: next(span["size"] for span in spans if text in span["text"])
                    for text in ("Wspornik", "Numer oferty:")
                }

        for text in ("Wspornik", "Numer oferty:"):
            with self.subTest(text=text):
                self.assertAlmostEqual(
                    font_sizes[150][text] / font_sizes[100][text],
                    1.5,
                    places=2,
                )

    def test_office_font_scale_setting_is_clamped_and_defaults_to_100_percent(self) -> None:
        self.assertEqual(office_font_scale_percent({}), 100)
        self.assertEqual(office_font_scale_percent({"office_font_scale_percent": "20"}), 50)
        self.assertEqual(office_font_scale_percent({"office_font_scale_percent": "220"}), 200)

    def test_both_offers_pdf_places_client_document_before_office_document(self) -> None:
        import pymupdf

        output = BytesIO()
        export_estimate_pdf(self.estimate, DEFAULT_SETTINGS, output, "both")
        with pymupdf.open(stream=output.getvalue(), filetype="pdf") as document:
            pages = [page.get_text() for page in document]

        client_offer_page = next(
            index for index, text in enumerate(pages)
            if "OFERTA HANDLOWA" in text and "Zestawienie pozycji oferty" in text
        )
        office_offer_page = next(
            index for index, text in enumerate(pages)
            if "WERSJA BIUROWA" in text
        )
        self.assertEqual(client_offer_page, 0)
        self.assertGreater(office_offer_page, client_offer_page)
        self.assertIn("Oferta i parametry kalkulacji", pages[office_offer_page])
        self.assertIn("Wspornik", pages[office_offer_page])
        self.assertEqual(len(pages), office_offer_page + 1)

    def test_office_row_height_setting_changes_padding_not_column_widths(self) -> None:
        captured_widths: list[list[float]] = []
        captured_styles: list[list[tuple]] = []

        def capture_table(data: list[list[object]], *args: object, **kwargs: object) -> object:
            widths = kwargs.get("colWidths")
            if widths and len(widths) == 12:
                captured_widths.append([float(width) for width in widths])
            return ReportLabTable(data, *args, **kwargs)

        original_set_style = ReportLabTable.setStyle

        def capture_style(table: ReportLabTable, style: ReportLabTableStyle) -> None:
            if len(getattr(table, "_argW", [])) == 12:
                captured_styles.append(style.getCommands())
            original_set_style(table, style)

        with tempfile.TemporaryDirectory() as temporary_directory:
            for value in ("1", "25"):
                with (
                    patch("reportlab.platypus.Table", side_effect=capture_table),
                    patch.object(ReportLabTable, "setStyle", capture_style),
                ):
                    export_estimate_pdf(
                        self.estimate,
                        {**DEFAULT_SETTINGS, "office_row_height_mm": value},
                        Path(temporary_directory) / f"office-rows-{value}.pdf",
                        "office",
                    )

        self.assertEqual(len(captured_widths), 2)
        compact_widths, expanded_widths = captured_widths
        self.assertEqual(compact_widths, expanded_widths)
        self.assertAlmostEqual(sum(compact_widths), 257 * mm)
        self.assertLessEqual(sum(compact_widths), A4[1] - 30 * mm - 12)

        def row_padding(style: list[tuple], command: str) -> float:
            return next(
                float(item[3])
                for item in style
                if item[0] == command
            )

        compact_top = row_padding(captured_styles[0], "TOPPADDING")
        expanded_top = row_padding(captured_styles[1], "TOPPADDING")
        compact_bottom = row_padding(captured_styles[0], "BOTTOMPADDING")
        expanded_bottom = row_padding(captured_styles[1], "BOTTOMPADDING")
        self.assertEqual(compact_top, 0)
        self.assertGreater(expanded_top, compact_top)
        self.assertLess(compact_bottom, expanded_bottom)

    def test_offer_pdf_tables_fit_inside_a4_page_margins(self) -> None:
        table_widths: list[list[float]] = []

        def capture_table(data: list[list[object]], *args: object, **kwargs: object) -> object:
            widths = kwargs.get("colWidths")
            if widths:
                table_widths.append([float(width) for width in widths])
            return ReportLabTable(data, *args, **kwargs)

        with tempfile.TemporaryDirectory() as temporary_directory:
            path = Path(temporary_directory) / "offer-width.pdf"
            with patch("reportlab.platypus.Table", side_effect=capture_table):
                export_estimate_pdf(self.estimate, DEFAULT_SETTINGS, path, "offer")

        available_width = A4[0] - 30 * mm
        self.assertTrue(table_widths)
        self.assertTrue(any(widths[0] == 9 * mm for widths in table_widths))
        for widths in table_widths:
            with self.subTest(widths=widths):
                self.assertLessEqual(sum(widths), available_width)

    def test_client_offer_exports_with_confirmed_izotechnika_profile_and_logo(self) -> None:
        with tempfile.TemporaryDirectory() as temporary_directory:
            path = Path(temporary_directory) / "izotechnika-offer.pdf"
            export_estimate_pdf(self.estimate, DEFAULT_SETTINGS, path, "offer")

            self.assertTrue(path.read_bytes().startswith(b"%PDF-"))
            self.assertGreater(path.stat().st_size, 4000)

    def test_total_only_offer_hides_per_item_names_and_unit_prices(self) -> None:
        doubled_estimate = {
            **self.estimate,
            "header": {
                **self.estimate["header"],
                "pricing_mode": "total_only",
                "net_total": "64.66",
                "vat_amount": "14.88",
                "gross_total": "79.54",
            },
            "items": [
                {
                    **self.estimate["items"][0],
                    "quantity": 2,
                    "line_net": "64.66",
                    "line_vat": "14.88",
                    "line_gross": "79.54",
                }
            ],
        }
        tables: list[list[list[object]]] = []

        def capture_table(data: list[list[object]], *args: object, **kwargs: object) -> object:
            tables.append(data)
            return ReportLabTable(data, *args, **kwargs)

        with tempfile.TemporaryDirectory() as temporary_directory:
            path = Path(temporary_directory) / "total-only.pdf"
            with patch("reportlab.platypus.Table", side_effect=capture_table):
                export_estimate_pdf(doubled_estimate, DEFAULT_SETTINGS, path, "offer")

            offer_table = next(table for table in tables if len(table[0]) == 5)
            offer_text = " ".join(
                str(cell.getPlainText()) if hasattr(cell, "getPlainText") else str(cell)
                for row in offer_table
                for cell in row
            )
            self.assertIn("Kompleksowa realizacja wypalanych elementów", offer_text)
            self.assertIn("79,54 zł", offer_text)
            self.assertNotIn("Wspornik", offer_text)
            self.assertEqual(offer_table[1][2], "2")
            self.assertNotIn("32,33 zł", offer_text)

    def test_whole_order_offer_and_internal_sheet_show_finished_quantity(self) -> None:
        whole_order_estimate = {
            **self.estimate,
            "items": [{
                **self.estimate["items"][0],
                "calculation_mode": "whole_order",
                "quantity": 12,
                "used_weight_kg": "4",
                "duration_seconds": 120,
                "material_cost": "48.00",
                "burning_cost": "16.67",
                "unit_net": "64.67",
                "unit_vat": "14.87",
                "unit_gross": "79.54",
                "line_net": "64.67",
                "line_vat": "14.87",
                "line_gross": "79.54",
            }],
        }
        tables: list[list[list[object]]] = []

        def capture_table(data: list[list[object]], *args: object, **kwargs: object) -> object:
            tables.append(data)
            return ReportLabTable(data, *args, **kwargs)

        with tempfile.TemporaryDirectory() as temporary_directory:
            for document_kind in ("offer", "internal"):
                tables.clear()
                path = Path(temporary_directory) / f"{document_kind}-batch.pdf"
                with patch("reportlab.platypus.Table", side_effect=capture_table):
                    export_estimate_pdf(whole_order_estimate, DEFAULT_SETTINGS, path, document_kind)

                table_width = 6 if document_kind == "offer" else 10
                detail_table = next(
                    table
                    for table in tables
                    if len(table[0]) == table_width
                )
                table_text = " ".join(
                    str(cell.getPlainText()) if hasattr(cell, "getPlainText") else str(cell)
                    for row in detail_table
                    for cell in row
                )
                self.assertIn("64,67 zł" if document_kind == "offer" else "64.67 zł", table_text)
                self.assertIn("12", table_text)
                if document_kind == "offer":
                    self.assertNotIn("Netto / szt.", table_text)
                else:
                    self.assertIn("Masa kg/szt. lub razem", table_text)
                    self.assertIn("48.00 zł", table_text)

    def test_pdf_rejects_unknown_document_type(self) -> None:
        with tempfile.TemporaryDirectory() as temporary_directory:
            path = Path(temporary_directory) / "bad.pdf"
            path.write_bytes(b"previous export")
            with self.assertRaises(ValueError):
                export_estimate_pdf(self.estimate, {}, path, "other")
            self.assertEqual(path.read_bytes(), b"previous export")
            self.assertEqual(list(Path(temporary_directory).glob(".bad.pdf.*.tmp")), [])

def _estimate_item(**overrides: object) -> dict[str, object]:
    item: dict[str, object] = {
        "element_name": "Wspornik",
        "material": "S235JR",
        "thickness_mm": "4",
        "quantity": 1,
        "price_per_kg": "12",
        "used_weight_kg": "2",
        "duration_seconds": 60,
        "burning_rate_per_hour": "500",
        "vat_percent": "23",
        "material_cost": "24.00",
        "burning_cost": "8.33",
        "unit_net": "32.33",
        "unit_vat": "7.44",
        "unit_gross": "39.77",
        "line_net": "32.33",
        "line_vat": "7.44",
        "line_gross": "39.77",
    }
    item.update(overrides)
    return item


def _make_estimate(items: list[dict[str, object]] | None = None, **header: object) -> dict[str, object]:
    items = items if items is not None else [_estimate_item()]
    net = sum(Decimal(str(item["line_net"])) for item in items)
    vat = sum(Decimal(str(item["line_vat"])) for item in items)
    return {
        "header": {
            "quote_number": "OF_Z-10_Firma",
            "customer_name": "Firma",
            "customer_tax_id": "",
            "customer_address": "",
            "order_number": "Z-10",
            "notes": "",
            "net_total": str(net),
            "vat_amount": str(vat),
            "gross_total": str(net + vat),
            "created_at": "2026-02-27T10:30:00+01:00",
            **header,
        },
        "items": items,
    }


def _make_note(item_count: int = 1, **overrides: object) -> dict[str, object]:
    note: dict[str, object] = {
        "document_number": "WZ-1/2026",
        "date": "26.10.2026",
        "customer_name": "Klient Łódź",
        "customer_tax_id": "1234567890",
        "order_number": "Z-1",
        "delivery_address": "ul. Żółta 1",
        "issuer": "Jan",
        "receiver": "Anna",
        "issued_packages": "",
        "returned_packages": "",
        "items": [
            {"product": f"Produkt {index}", "description": f"Opis {index}", "description2": "",
             "quantity": "1", "unit": "szt", "notes": ""}
            for index in range(1, item_count + 1)
        ],
    }
    note.update(overrides)
    return note


def _pdf_document(data: bytes):
    import pymupdf

    return pymupdf.open(stream=data, filetype="pdf")


def _pdf_text(data: bytes) -> str:
    document = _pdf_document(data)
    try:
        return " ".join(" ".join(page.get_text() for page in document).split())
    finally:
        document.close()


def _spans(page) -> list[dict]:
    return [
        span
        for block in page.get_text("dict")["blocks"]
        for line in block.get("lines", [])
        for span in line["spans"]
        if span["text"].strip()
    ]


def _png_bytes(size: tuple[int, int] = (40, 20)) -> bytes:
    buffer = BytesIO()
    PillowImage.new("RGB", size, color=(200, 30, 30)).save(buffer, format="PNG")
    return buffer.getvalue()
